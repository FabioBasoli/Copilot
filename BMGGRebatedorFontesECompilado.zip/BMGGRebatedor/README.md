# Introduction 
Projeto Rebatedor BMG Granito

# Getting Started
1.	Instalação:
    - Executar esta linha de comando como administrador:
    - sc create BMGGAutorizador binpath=C:\Users\sanses\repos\BMGGRebatedor.exe
2.	Desinstalação:
    - Executar esta linha de comando como administrador:
    - sc delete BMGGRebatedor
3.	Iniciar o serviço:
    - Executar esta linha de comando como administrador:
    - sc start BMGGRebatedor
4.	Parar o serviço:
    - Executar esta linha de comando como administrador:
    - sc stop BMGGRebatedor

# Contribute
- Silmar Sanches