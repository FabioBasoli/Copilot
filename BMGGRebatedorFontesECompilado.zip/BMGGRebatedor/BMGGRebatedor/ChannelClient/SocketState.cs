﻿namespace BMGGRebatedor
{
    public enum SocketState
    {
        Connected = 0,
        Disconnected = 1,
        Recycling = 2,
        SendError = 3,
        ReceiveError = 4,
        Disconnecting = 5,
        RecyclingChannel,
        DisconnectedByClient,
        DisconnectadBySocketLoss,
        DisconnectedByServerTimeout,
        DisconnectedByServerFinalizing,
        DisconnectedBySocketError,
        DisconnectedByMessageError,
        DisconnectedByGenericError
    }
}
