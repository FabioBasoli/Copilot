﻿using System;
using System.Text;
using System.Threading;
using System.Net.Sockets;
using BMGGRebatedor.Utils;
using BMGGRebatedor.BMGGLog;
using System.Collections.Generic;
using BMGGRebatedor.BMGGIso.Rebut;

namespace BMGGRebatedor
{
    public class ClientWorker
    {

        CommonChannelClientEvents events;

        LogManagement log;              // instancia de logs

        TcpClient socket;               // socket

        string threadName;              // nome da thread

        DateTime threadAge;             // tempo de vida da thread

        List<byte> buffer;              // buffer de bytes recebidos

        byte[] buff;                    // buffer usado para testar conexões

        NetworkStream stream;           // fluxo de dados

        SocketState ConnectionState;    // indica se continua ouvindo ou finaliza esta thread (false continua, true finaliza)

        string rede;

        readonly object syncRunning = new object();

        #region construtor
        public ClientWorker(TcpClient sck, string name, string rede, DateTime data)
        {
            events = CommonChannelClientEvents.Instance;

            buff = new byte[1];

            CriaLog(rede);

            this.rede = rede;
            this.socket = sck;
            this.threadAge = data;
            this.threadName = name;
            this.stream = sck.GetStream();
        }
        #endregion

        #region cria log
        private void CriaLog(string rede)
        {
            Levels level = (Levels) Convert.ToInt16(ConfigClass.GetLogLevelChannelClient());
            log = new LogManagement(ConfigClass.GetLogPathServer(), $"LogCanalClient-{rede}", level);
        }
        #endregion
        
        #region setup TcpClient
        public void SetupTcpClient()
        {
            try
            {
                ClientRun();
            }
            finally
            {
                stream.Close();
                socket.Close();
            }
        }
        #endregion

        #region metodo Run
        private void ClientRun()
        {
            List<byte> resposta = new List<byte>();

            #region while
            while (!ControllerService.StopRunning && ConnectionState == SocketState.Connected)
            {
                CheckConnection();
                try
                {
                    if (ConnectionState == SocketState.Connected)
                    {
                        buffer = new List<byte>();

                        if (socket.Available > 0)
                        {
                            while (socket.Available > 0)
                            {
                                byte[] bytes = new byte[socket.Available];
                                stream.Read(bytes, 0, socket.Available);

                                buffer.AddRange(bytes);

                                log.LogFull($"[{rede}-{this.threadName}] Bytes recebidos: {bytes.Length}");
                                log.LogFull($"[{rede}-{this.threadName}] REC: {BitConverter.ToString(bytes)}");
                            }

                            if (buffer.Count > 2)
                            {
                                ToRebut rebate = new ToRebut(buffer.ToArray(), rede);
                                try
                                {
                                    resposta = rebate.Proccess();
                                }
                                catch
                                {
                                    resposta = buffer;
                                }
                            }
                            else
                            {
                                throw new Exception($"[{rede}-{this.threadName}] Mensagem recebida era igual ou menor que 2 bytes");
                            }
                        }
                    }
                    Thread.Sleep(100);
                }
                catch (SocketException se)
                {
                    log.LogError($"[{rede}-{this.threadName}] Erro de SOCKET: {se.ErrorCode}-{se.Message}");
                    ConnectionState = SocketState.DisconnectedBySocketError;
                    SendMessage(Encoding.ASCII.GetBytes(se.Message));
                }
                catch (Exception ex)
                {
                    log.LogError($"[{rede}-{this.threadName}] Erro: {ex.Message}");
                    ConnectionState = SocketState.DisconnectedByGenericError;
                    SendMessage(Encoding.ASCII.GetBytes(ex.Message));
                }

                // verifica resposta na fila
                if (resposta.Count > 0)
                {
                    log.LogFull($"[{rede}-{this.threadName}] RESP: {BitConverter.ToString(resposta.ToArray())}");
                    SendMessage(resposta.ToArray());
                    resposta.Clear();
                }
            }
            #endregion

            #region switch
            switch (ConnectionState)
            {
                case SocketState.Connected:
                case SocketState.DisconnectedByClient:
                    events.OnClientDisconnectToChannelEvents(this, this.threadName, rede);
                    break;
                case SocketState.DisconnectadBySocketLoss:
                    events.OnClientConnectionLostEvents(this, this.threadName, rede);
                    break;
                case SocketState.DisconnectedByServerTimeout:
                    events.OnClientReceiveDisconnectTimeoutEvents(this, this.threadName, rede);
                    break;
                case SocketState.DisconnectedByServerFinalizing:
                    events.OnClientDisconnectByServerEvent(this, this.threadName, rede);
                    break;
                case SocketState.DisconnectedBySocketError:
                    events.OnErrorProcessingEvent(this, this.threadName, "Desconectado por erro de Socket", rede);
                    break;
                case SocketState.DisconnectedByMessageError:
                    events.OnErrorProcessingEvent(this, this.threadName, "Desconectado por erro na mensagem", rede);
                    break;
                case SocketState.DisconnectedByGenericError:
                    events.OnErrorProcessingEvent(this, this.threadName, "Erro ao processar transação", rede);
                    break;
                default:
                    events.OnErrorProcessingEvent(this, this.threadName, "Erro ao processar transação", rede);
                    break;
            }
            #endregion

        }
        #endregion

        #region metodos de resposta
        private void CheckConnection()
        {
            try
            {
                if (socket.Client.Poll(0, SelectMode.SelectRead))
                {

                    if (socket.Client.Receive(buff, SocketFlags.Peek) == 0)
                    {
                        ConnectionState = SocketState.DisconnectedByClient;
                    }
                    else
                    {
                        ConnectionState = SocketState.Connected;
                    }
                }
                else if (socket.Client.Poll(0, SelectMode.SelectWrite))
                {
                    ConnectionState = SocketState.Connected;
                }
            }
            catch (SocketException se)
            {
                log.LogError($"[{this.threadName}] Erro de SOCKET: {se.Message}-{se.ErrorCode}");
                ConnectionState = SocketState.DisconnectedBySocketError;
            }
            catch (Exception ex)
            {
                log.LogError($"[{this.threadName}] Erro: {ex.Message}");
                ConnectionState = SocketState.DisconnectedByGenericError;
            }
        }

        private void SendMessage(byte[] msg)
        {
            CheckConnection();
            if (ConnectionState == SocketState.Connected)
            {
                try
                {
                    socket.GetStream().Write(msg, 0, msg.Length);
                }
                catch (SocketException se)
                {
                    log.LogError($"[{this.threadName}] Socket do cliente desconectado. Resposta não enviada: {se.Message}");
                }
                catch (Exception ex)
                {
                    log.LogError($"[{this.threadName}] Erro: {ex.Message}");
                }
            }
            else
            {
                log.LogError($"[{this.threadName}] Socket do cliente desconectado. Mensagem não enviada");
            }
        }
        #endregion

    }
}
