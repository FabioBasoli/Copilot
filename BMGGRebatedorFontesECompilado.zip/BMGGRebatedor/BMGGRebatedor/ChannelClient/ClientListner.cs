﻿using System;
using System.Net;
using System.Threading;
using System.Net.Sockets;
using BMGGRebatedor.Utils;
using BMGGRebatedor.BMGGLog;

namespace BMGGRebatedor
{
    public class ClientListner
    {
        string redeListner;
        string redeTipo;

        LogManagement log;

        TcpListener tcpListener;

        CommonChannelClientEvents events;

        readonly object syncRunning = new object();

        #region construtor
        public void SetupListner(object rede)
        {
            events = CommonChannelClientEvents.Instance;

            events.OnClientConnectToChannel += Events_OnClientConnectToChannel;                     // quando o cliente se conecta no server
            events.OnClientDisconnectToChannel += Events_OnClientDisconnectToChannel;               // quando o cliente se desconecta do server
            events.OnClientConnectionLost += Events_OnClientConnectionLost;                         // quando cliente se desconectou do server inesperadamente
            events.OnClientReceiveDisconnectTimeout += Events_OnClientReceiveDisconnectTimeout;     // quando cliente é desconectado pelo server por timeout
            events.OnClientDisconnectByServer += Events_OnClientDisconnectByServer;                 // quando o server entra em processo de finalização
            events.OnErrorProcessing += Events_OnErrorProcessing;                                   // quando há erro de processamento a nivel de socket (cliente/server)

            var vAux = (string)rede;

            if (vAux.Length == 2)
            {
                redeListner = vAux;
                redeTipo = string.Empty;
            }
            else
            {
                redeListner = vAux.Substring(0, 2);
                redeTipo = vAux.Substring(2);
            }
            redeListner = ((string)rede).Substring(0,2);

            CriaLog();

            IniciaSocketListner();
        }
        #endregion

        #region cria log
        private void CriaLog()
        {
            Levels level = (Levels) Convert.ToInt16(ConfigClass.GetLogLevelChannelClient());
            log = new LogManagement(ConfigClass.GetLogPathServer(), "LogCanalClient", level);
        }
        #endregion
        
        #region reinicia socket
        private void IniciaSocketListner()
        {
            var porta = string.Empty;
            ControllerService.StopRunning = false;

            switch (redeListner.ToUpper())
            {
                case "07": porta = ConfigClass.GetPortaGlobal(); break;
                case "08": porta = ConfigClass.GetPortaFepas(); break;
                case "02": porta = ConfigClass.GetPortaVisa(); break;
                case "03": 
                    porta = ConfigClass.GetPortaMaster();
                    porta = redeTipo == "C" ? porta.Replace("03", "33") : porta;
                    break;
                case "04": porta = ConfigClass.GetPortaElo(); break;
            }

            tcpListener = new TcpListener(IPAddress.Any, Convert.ToInt32(porta));
            log.LogInformation($"Canal '{redeListner}-{redeTipo}' configurado: IP -> {IPAddress.Loopback}, PORT -> {porta}");

            StartListner();
            ReceiveListner();
        }
        #endregion

        #region start/stop
        public void StartListner()
        {
            try
            {
                ControllerService.StopRunning = false;
                tcpListener.Start();
                log.LogInformation($"Canal '{redeListner}' iniciado com sucesso! Aguardando conexões...");
            }
            catch (Exception ex)
            {
                tcpListener.Stop();
                log.LogError($"Erro ao iniciar Client-Listner: {redeListner}-{ex.Message}");
            }
        }
        #endregion

        #region Accept connections
        private void ReceiveListner()
        {
            DateTime lastMessage = DateTime.Now;

            while (!ControllerService.StopRunning)
            {
                if (tcpListener.Pending())
                {
                    lastMessage = DateTime.Now;

                    long thrID = new Random().Next(10000, 50000);
                    TcpClient tcpClient = tcpListener.AcceptTcpClient();

                    ClientWorker clientProp = new ClientWorker(tcpClient, thrID.ToString(), redeListner, DateTime.Now);

                    Thread thread = new Thread(StartNewClient);
                    thread.IsBackground = true;
                    thread.Name = thrID.ToString();

                    thread.Start(clientProp);

                    log.LogInformation($"Solicitação de conexão recebida: thread {thread.Name} pendente");

                    events.OnClientConnectToChannelEvents(this, thread.Name, redeListner);
                }
                else
                {
                    lock (syncRunning)
                    {
                        if (ControllerService.StopRunning)
                        {
                            break;
                        }
                    }

                    Thread.Sleep(100);
                }

                Thread.Sleep(50);
            }

            log.LogInformation($"Bloqueio de novas conexões ativado. Conexões atuais {ControllerService.LstThreadClient.Count}");

            if (ControllerService.StopRunning)
            {
                log.LogInformation("Iniciando procedimento de finalização do servidor");
                log.LogInformation($"Número de clientes conectados neste momento {ControllerService.LstThreadClient.Count}");

                if (ControllerService.LstThreadClient.Count > 0)
                {
                    log.LogInformation("Aguardando desconexão de clientes...");
                    log.LogInformation($"Clientes remanescentes {ControllerService.LstThreadClient.Count}, forçando desconexão...");

                    while (ControllerService.LstThreadClient.Count > 0)
                    {
                        Thread.Sleep(200);
                    }
                }

                tcpListener.Stop();
                log.LogInformation($" *** Canal '{redeListner}' fechado *** ");
            }
        }
        #endregion

        #region cria thread com novo cliente
        private void StartNewClient(object param)
        {
            ClientWorker client = (ClientWorker)param;
            client.SetupTcpClient();
        }
        #endregion

        #region eventos
        private void Events_OnClientConnectToChannel(object sender, ClientConnectToChannelEventArgs e)
        {
            lock (syncRunning)
            {
                if (e.rede == redeListner)
                {
                    ControllerService.LstThreadClient.Add(e.threadID);
                    log.LogInformation($"[{e.threadID}] Rede: {e.rede} - Cliente conectou. Total de conexões geral: {ControllerService.LstThreadClient.Count}");   
                }
            }
        }

        private void Events_OnClientDisconnectToChannel(object sender, ClientDisconnectToChannelEventArgs e)
        {
            lock (syncRunning)
            {
                if (e.rede == redeListner)
                {
                    ControllerService.LstThreadClient.Remove(e.threadID);
                    log.LogInformation($"[{e.threadID}] Rede: {e.rede} - Cliente desconectou. Total de conexões geral: {ControllerService.LstThreadClient.Count}");
                }
            }
        }

        private void Events_OnClientConnectionLost(object sender, ClientSendDisconnectTimeoutEventArgs e)
        {
            lock (syncRunning)
            {
                if (e.rede == redeListner)
                {
                    ControllerService.LstThreadClient.Remove(e.threadID);
                    log.LogInformation($"[{e.threadID}] Rede: {e.rede} - Conexão com cliente perdida. Total de conexões geral: {ControllerService.LstThreadClient.Count}");
                }
            }
        }

        private void Events_OnClientReceiveDisconnectTimeout(object sender, ClientReceiveDisconnectTimeoutEventArgs e)
        {
            lock (syncRunning)
            {
                if (e.rede == redeListner)
                {
                    ControllerService.LstThreadClient.Remove(e.threadID);
                    log.LogInformation($"[{e.threadID}] Rede: {e.rede} - Cliente desconectado pelo server: timeout terminal. Total de conexões geral: {ControllerService.LstThreadClient.Count}");   
                }
            }
        }

        private void Events_OnClientDisconnectByServer(object sender, ClientDisconnectByServerEventArgs e)
        {
            lock (syncRunning)
            {
                if (e.rede == redeListner)
                {
                    ControllerService.LstThreadClient.Remove(e.threadID);
                    log.LogInformation($"[{e.threadID}] Rede: {e.rede} - Cliente desconectado pelo server: Servidor em processo de desligamento. Total de conexões geral: {ControllerService.LstThreadClient.Count}");   
                }
            }
        }

        private void Events_OnErrorProcessing(object sender, OnErrorProcessingEventArgs e)
        {
            lock (syncRunning)
            {
                if (e.rede == redeListner)
                {
                    ControllerService.LstThreadClient.Remove(e.threadID);
                    log.LogInformation($"[{e.threadID}] Rede: {e.rede} - Cliente desconectado, erro de processamento. Total de conexões geral: {ControllerService.LstThreadClient.Count}");   
                }
            }
        }
        #endregion

    }
}
