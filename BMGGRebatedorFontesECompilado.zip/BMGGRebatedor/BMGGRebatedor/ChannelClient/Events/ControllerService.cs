﻿using System.Collections.Generic;

namespace BMGGRebatedor
{
    public static class ControllerService
    {
        public static bool StopRunning { get; set; }

        public static List<string> LstThreadClient { get; set; }
    }
}
