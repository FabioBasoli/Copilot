﻿using System;

namespace BMGGRebatedor
{
    public class OnErrorProcessingEventArgs : EventArgs
    {
        public string threadID { get; set; }
        public string msgError { get; set; }
        public string rede { get; set; }
        
        public OnErrorProcessingEventArgs(string _thr, string _msgErro, string _rede)
        {
            threadID = _thr;
            msgError = _msgErro;
            rede = _rede;
        }
    }
}
