﻿using System;

namespace BMGGRebatedor
{
    public class ClientConnectToChannelEventArgs : EventArgs
    {
        public string threadID { get; set; }
        public string rede { get; set; }
        
        public ClientConnectToChannelEventArgs(string _thr, string _rede)
        {
            threadID = _thr;
            rede = _rede;
        }
    }
}
