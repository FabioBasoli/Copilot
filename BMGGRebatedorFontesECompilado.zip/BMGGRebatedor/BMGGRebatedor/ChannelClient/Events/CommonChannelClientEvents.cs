﻿using System;

namespace BMGGRebatedor
{
    public class CommonChannelClientEvents
    {
        private static CommonChannelClientEvents instance;

        public event EventHandler<ClientConnectToChannelEventArgs> OnClientConnectToChannel;
        public event EventHandler<ClientDisconnectToChannelEventArgs> OnClientDisconnectToChannel;
        public event EventHandler<ClientSendDisconnectTimeoutEventArgs> OnClientConnectionLost;
        public event EventHandler<ClientReceiveDisconnectTimeoutEventArgs> OnClientReceiveDisconnectTimeout;
        public event EventHandler<ClientDisconnectByServerEventArgs> OnClientDisconnectByServer;
        public event EventHandler<OnErrorProcessingEventArgs> OnErrorProcessing;

        private CommonChannelClientEvents() { }

        public static CommonChannelClientEvents Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CommonChannelClientEvents();
                }
                return instance;
            }
        }

        public void OnClientConnectToChannelEvents(object sender, string thr, string rede)
        {
            OnClientConnectToChannel.Raise(sender, new ClientConnectToChannelEventArgs(thr, rede));
        }

        public void OnClientDisconnectToChannelEvents(object sender, string thr, string rede)
        {
            OnClientDisconnectToChannel.Raise(sender, new ClientDisconnectToChannelEventArgs(thr, rede));
        }

        public void OnClientConnectionLostEvents(object sender, string thr, string rede)
        {
            OnClientConnectionLost.Raise(sender, new ClientSendDisconnectTimeoutEventArgs(thr, rede));
        }

        public void OnClientReceiveDisconnectTimeoutEvents(object sender, string thr, string rede)
        {
            OnClientReceiveDisconnectTimeout.Raise(sender, new ClientReceiveDisconnectTimeoutEventArgs(thr, rede));
        }

        public void OnClientDisconnectByServerEvent(object sender, string thr, string rede)
        {
            OnClientDisconnectByServer.Raise(sender, new ClientDisconnectByServerEventArgs(thr, rede));
        }

        public void OnErrorProcessingEvent(object sender, string thr, string msg, string rede)
        {
            OnErrorProcessing.Raise(this, new OnErrorProcessingEventArgs(thr, msg, rede));
        }

    }
}
