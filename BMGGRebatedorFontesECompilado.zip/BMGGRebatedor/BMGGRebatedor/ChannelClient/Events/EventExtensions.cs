﻿using System;

namespace BMGGRebatedor
{
    public static class EventExtensions
    {
        static readonly object syncEvent = new object();

        public static void Raise<T>(this EventHandler<T> theEvent, object source, T args) where T : EventArgs
        {
            lock (syncEvent) { if (theEvent != null) { theEvent(source, args); } }
        }
    }
}
