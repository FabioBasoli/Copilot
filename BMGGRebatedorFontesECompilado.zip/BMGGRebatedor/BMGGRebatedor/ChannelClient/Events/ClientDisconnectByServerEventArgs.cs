﻿using System;

namespace BMGGRebatedor
{
    public class ClientDisconnectByServerEventArgs : EventArgs
    {
        public string threadID { get; set; }
        public string rede { get; set; }
        
        public ClientDisconnectByServerEventArgs(string _thr, string _rede)
        {
            threadID = _thr;
            rede = _rede;
        }
    }
}
