using System.Collections.Generic;

namespace BMGGRebatedor.Share
{
    public static class ControllerChannelClient
    {
        public static List<string> LstThreadClient { get; set; }
    }
}