namespace BMGGRebatedor.Share
{
    public static class ControllerClientListner
    {
        public static bool StopRunningAccept { get; set; }
        public static bool StopRunningServer { get; set; }
    }
}