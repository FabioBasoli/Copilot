using System.IO;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BMGGRebatedor
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) => Host.CreateDefaultBuilder(args) 
            .UseWindowsService()
            .ConfigureAppConfiguration((hostContext, config) =>
            {
                config.SetBasePath(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location));
                config.AddJsonFile("appsettings.json", false, true);
                config.AddCommandLine(args);
            })
            .ConfigureServices((hostContext, services) => { services.AddHostedService<Worker>(); });
    }
}