using System;
using System.IO;
using System.Threading;
using BMGGRebatedor.Share;
using BMGGRebatedor.Utils;
using BMGGRebatedor.BMGGLog;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;

using Microsoft.Extensions.Logging;

namespace BMGGRebatedor
{
    public class Worker : BackgroundService
    {
        LogManagement log;
        private readonly IConfiguration _config;

        #region construtor
        public Worker(IConfiguration config)
        {
            _config = config;
        }
        #endregion

        #region cria log
        private void CriaLog()
        {
            Levels level = (Levels) Convert.ToInt16(ConfigClass.GetLogLevelChannelClient());
            log = new LogManagement(ConfigClass.GetLogPathServer(), "LogService", level);
        }
        #endregion
        
        #region executeasync
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                await Task.Delay(1000, stoppingToken);
            }
        }
        #endregion
        
        #region on start
        public override Task StartAsync(CancellationToken cancellationToken)
        {
            ConfigClass.Instantiate(_config);
            ControllerService.StopRunning = false;

            #region verificando pastas de logs e cache
            var path = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            var pathLog = Path.Combine(path, "LOGS");
            if (!Directory.Exists(pathLog)) Directory.CreateDirectory(pathLog);
            #endregion

            #region iniciando fila de log
            QueueLog.Instantiate();
            CriaLog();
            #endregion

            log.LogInformation("Rebatedor BMG-Granito sendo iniciado");

            #region iniciando canais
            // controlador de threads do canal de clientes
            log.LogInformation("Iniciando controlador de Threads do canal de clientes");
            ControllerService.LstThreadClient = new List<string>();
            log.LogInformation("Controlador de Threads iniciado com sucesso.");

            // iniciando o canal de clientes
            ClientListner cListnerGlobal = new ClientListner();
            Thread threadClientesGlobal = new Thread(cListnerGlobal.SetupListner);
            threadClientesGlobal.IsBackground = true;
            threadClientesGlobal.Name = "Client-Listner-Global";
            threadClientesGlobal.Start("07");
            log.LogInformation($"Thread {threadClientesGlobal.Name} iniciada com sucesso");

            ClientListner cListnerFepas = new ClientListner();
            Thread threadClientesFepas = new Thread(cListnerFepas.SetupListner);
            threadClientesFepas.IsBackground = true;
            threadClientesFepas.Name = "Client-Listner-Fepas";
            threadClientesFepas.Start("08");
            log.LogInformation($"Thread {threadClientesFepas.Name} iniciada com sucesso");
            
            ClientListner cListnerVisa = new ClientListner();
            Thread threadClientesVisa = new Thread(cListnerVisa.SetupListner);
            threadClientesVisa.IsBackground = true;
            threadClientesVisa.Name = "Client-Listner-Visa";
            threadClientesVisa.Start("02");
            log.LogInformation($"Thread {threadClientesVisa.Name} iniciada com sucesso");

            ClientListner cListnerMasterD = new ClientListner();
            Thread threadClientesMasterD = new Thread(cListnerMasterD.SetupListner);
            threadClientesMasterD.IsBackground = true;
            threadClientesMasterD.Name = "Client-Listner-MasterD";
            threadClientesMasterD.Start("03D");
            log.LogInformation($"Thread {threadClientesMasterD.Name} iniciada com sucesso");
            
            ClientListner cListnerMasterC = new ClientListner();
            Thread threadClientesMasterC = new Thread(cListnerMasterC.SetupListner);
            threadClientesMasterC.IsBackground = true;
            threadClientesMasterC.Name = "Client-Listner-MasterC";
            threadClientesMasterC.Start("03C");
            log.LogInformation($"Thread {threadClientesMasterC.Name} iniciada com sucesso");

            ClientListner cListnerElo = new ClientListner();
            Thread threadClientesElo = new Thread(cListnerElo.SetupListner);
            threadClientesElo.IsBackground = true;
            threadClientesElo.Name = "Client-Listner-Elo";
            threadClientesElo.Start("04");
            log.LogInformation($"Thread {threadClientesElo.Name} iniciada com sucesso");
            #endregion

            log.LogInformation("Rebatedor BMG-Granito iniciado com sucesso ***");
            
            return base.StartAsync(cancellationToken);
        }
        #endregion

        #region on stop
        public override Task StopAsync(CancellationToken cancellationToken)
        {
            if (log == null) CriaLog();
            StopService(log);
            log.LogInformation(" *** REBATEDOR BMG-GRANITO FINALIZADO *** ");

            return base.StopAsync(cancellationToken);
        }
        #endregion

        #region processo de stop do serviço
        private void StopService(LogManagement _log)
        {
            // logando o numero de threads no momento do desligamento do servidor
            _log.LogInformation($"Clientes conectados: {ControllerChannelClient.LstThreadClient.Count}");

            // finalizando canal de clientes
            ControllerClientListner.StopRunningAccept = true;
            ControllerClientListner.StopRunningServer = true;

            int contador = 0;
            while (ControllerChannelClient.LstThreadClient.Count > 0 && contador < 20)
            {
                Thread.Sleep(1000);
                contador++;
            }

            Thread.Sleep(2000);
        }
        #endregion
        
    }
}