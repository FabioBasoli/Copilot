using Microsoft.Extensions.Configuration;

namespace BMGGRebatedor.Utils
{
    public static class ConfigClass
    {
        private static IConfiguration config;

        public static void Instantiate(IConfiguration _config)
        {
            config = _config;
        }
        
        internal static string GetLogLevelChannelClient()
        {
            return config.GetValue<string>("logLevelChannelClient");
        }
        
        internal static string GetLogPathServer()
        {
            return config.GetValue<string>("logPathServer");
        }

        internal static string GetPortaGlobal()
        {
            return config.GetValue<string>("portaGlobal");
        }

        internal static string GetPortaFepas()
        {
            return config.GetValue<string>("portaFepas");
        }
        
        internal static string GetPortaVisa()
        {
            return config.GetValue<string>("portaVisa");
        }
        
        internal static string GetPortaMaster()
        {
            return config.GetValue<string>("portaMaster");
        }
        
        internal static string GetPortaElo()
        {
            return config.GetValue<string>("portaElo");
        }
    }
}