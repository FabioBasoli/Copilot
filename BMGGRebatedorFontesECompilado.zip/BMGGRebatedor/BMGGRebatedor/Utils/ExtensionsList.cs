﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace BMGGRebatedor.Utils
{
    public static class ExtensionsList
    {
        public static List<T> CloneList<T>(this List<T> listToClone) where T : ICloneable
        {
            return listToClone.Select(item => (T)item.Clone()).ToList();
        }
    }
}
