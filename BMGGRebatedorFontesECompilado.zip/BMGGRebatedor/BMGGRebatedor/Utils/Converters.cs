﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;

namespace BMGGRebatedor.Utils
{
    public sealed class Converters
    {

        #region ler array de bytes parcial
        public string GetStringByArray(byte[] arr, int inicio, int final)
        {
            byte[] arrParcial = new byte[final];
            Buffer.BlockCopy(arr, inicio, arrParcial, 0, final);
            return Encoding.ASCII.GetString(arrParcial);
        }
        #endregion

        #region BCD para String / String para BCD
        public byte[] StrToBcd(string input)
        {
            byte[] output = new byte[(input.Length + 1) / 2];
            char[] chars = input.ToCharArray();
            int current = 0;
            while (current < chars.Length)
            {
                output[current / 2] = (byte)(int.Parse(chars[current].ToString()) << 4);
                if (current + 1 < chars.Length) { output[current / 2] |= (byte)int.Parse(chars[current + 1].ToString()); }
                current += 2;
            }
            return output;
        }

        public string BcdToStr(byte[] bytes)
        {
            StringBuilder temp = new StringBuilder(bytes.Length * 2);
            for (int i = 0; i < bytes.Length; i++)
            {
                temp.Append((byte)((bytes[i] & 0xf0) >> 4));
                temp.Append((byte)(bytes[i] & 0x0f));
            }
            return temp.ToString();
        }

        public string BcdToStr(byte[] bytes, int inicial, int final)
        {
            byte[] arr = new byte[final];
            Buffer.BlockCopy(bytes, inicial, arr, 0, final);
            return BcdToStr(arr);
        }

        public string GetBcdByArray(byte[] arr, int inicio, int final)
        {
            byte[] arrParcial = new byte[final];
            Buffer.BlockCopy(arr, inicio, arrParcial, 0, final);
            return BitConverter.ToString(arrParcial).Replace("-", "");
        }

        public string GetAsciiByArray(byte[] arr, int inicio, int final)
        {
            byte[] arrParcial = new byte[final];
            Buffer.BlockCopy(arr, inicio, arrParcial, 0, final);
            return Encoding.ASCII.GetString(arrParcial);
        }
        #endregion

        #region Comprimir e descomprimir string
        public byte[] EncodeStr(String txt)
        {
            int length = txt.Length;
            byte[] encoded = new byte[(int)(Math.Ceiling((double)length * 6 / 8))];
            byte[] strBytes = new byte[length];
            int i, posEncoded;

            for (i = 0; i < length; i++)
            {
                strBytes[i] = (byte)toValue(txt[i]);
            }

            for (i = 0, posEncoded = 0; i + 4 <= length; i += 4, posEncoded += 3)
            {
                encoded[posEncoded] = (byte)((int)strBytes[i] << 2 | (int)strBytes[i + 1] >> 4);
                encoded[posEncoded + 1] = (byte)((int)strBytes[i + 1] << 4 | (int)strBytes[i + 2] >> 2);
                encoded[posEncoded + 2] = (byte)((int)strBytes[i + 2] << 6 | (int)strBytes[i + 3]);
            }

            if (i < length)
            {
                encoded[posEncoded] = (byte)((int)strBytes[i] << 2);
                if (i + 1 < length)
                {
                    encoded[posEncoded] = (byte)((int)encoded[posEncoded] | (int)strBytes[i + 1] >> 4);
                    encoded[posEncoded + 1] = (byte)((int)strBytes[i + 1] << 4);
                }

                if (i + 2 < length)
                {
                    encoded[posEncoded + 1] = (byte)((int)encoded[posEncoded + 1] | (int)strBytes[i + 2] >> 2);
                    encoded[posEncoded + 2] = (byte)((int)strBytes[i + 2] << 6);
                }
            }
            return encoded;
        }
        
        public String DecodeStr(byte[] encoded)
        {
            string retorno = "";
            int i, fator = 1, intByte;

            for (i = 0; i < encoded.Length; i++)
            {
                if (fator == 1)
                {
                    retorno += toChar((int)encoded[i] >> 2);
                    fator++;
                }
                else if (fator == 2)
                {
                    intByte = (int)encoded[i - 1] << 6;
                    intByte = (byte)intByte >> 2;
                    intByte = (byte)intByte | (int)encoded[i] >> 4;
                    retorno += toChar(intByte);
                    fator++;
                }
                else if (fator == 3)
                {
                    intByte = (int)encoded[i - 1] << 4;
                    intByte = (byte)intByte >> 2;
                    intByte = (byte)intByte | (int)encoded[i] >> 6;
                    retorno += toChar(intByte);

                    intByte = (int)encoded[i] << 2;
                    intByte = (byte)intByte >> 2;
                    retorno += toChar(intByte);
                    fator = 1;
                }
            }
            return retorno;
        }

        #region matrizes de troca de valores
        int toValue(char ch)
        {
            int chaVal = 0;
            switch (ch)
            {
                case '0': chaVal = 0; break;
                case '1': chaVal = 1; break;
                case '2': chaVal = 2; break;
                case '3': chaVal = 3; break;
                case '4': chaVal = 4; break;
                case '5': chaVal = 5; break;
                case '6': chaVal = 6; break;
                case '7': chaVal = 7; break;
                case '8': chaVal = 8; break;
                case '9': chaVal = 9; break;
                case 'A': chaVal = 10; break;
                case 'B': chaVal = 11; break;
                case 'C': chaVal = 12; break;
                case 'D': chaVal = 13; break;
                case 'E': chaVal = 14; break;
                case 'F': chaVal = 15; break;
                case 'G': chaVal = 16; break;
                case 'H': chaVal = 17; break;
                case 'I': chaVal = 18; break;
                case 'J': chaVal = 19; break;
                case 'K': chaVal = 20; break;
                case 'L': chaVal = 21; break;
                case 'M': chaVal = 22; break;
                case 'N': chaVal = 23; break;
                case 'O': chaVal = 24; break;
                case 'P': chaVal = 25; break;
                case 'Q': chaVal = 26; break;
                case 'R': chaVal = 27; break;
                case 'S': chaVal = 28; break;
                case 'T': chaVal = 29; break;
                case 'U': chaVal = 30; break;
                case 'V': chaVal = 31; break;
                case 'W': chaVal = 32; break;
                case 'X': chaVal = 33; break;
                case 'Y': chaVal = 34; break;
                case 'Z': chaVal = 35; break;
                case ' ': chaVal = 36; break;
                case '.': chaVal = 37; break;
                case '=': chaVal = 38; break;
                case ',': chaVal = 39; break;
                case '*': chaVal = 40; break;
                case '\\': chaVal = 41; break;
                case '-': chaVal = 42; break;
                case '/': chaVal = 43; break;
                default: chaVal = 0; break;
            }
            return chaVal;
        }
        char toChar(int val)
        {
            char ch = ' ';
            switch (val)
            {
                case 0: ch = '0'; break;
                case 1: ch = '1'; break;
                case 2: ch = '2'; break;
                case 3: ch = '3'; break;
                case 4: ch = '4'; break;
                case 5: ch = '5'; break;
                case 6: ch = '6'; break;
                case 7: ch = '7'; break;
                case 8: ch = '8'; break;
                case 9: ch = '9'; break;
                case 10: ch = 'A'; break;
                case 11: ch = 'B'; break;
                case 12: ch = 'C'; break;
                case 13: ch = 'D'; break;
                case 14: ch = 'E'; break;
                case 15: ch = 'F'; break;
                case 16: ch = 'G'; break;
                case 17: ch = 'H'; break;
                case 18: ch = 'I'; break;
                case 19: ch = 'J'; break;
                case 20: ch = 'K'; break;
                case 21: ch = 'L'; break;
                case 22: ch = 'M'; break;
                case 23: ch = 'N'; break;
                case 24: ch = 'O'; break;
                case 25: ch = 'P'; break;
                case 26: ch = 'Q'; break;
                case 27: ch = 'R'; break;
                case 28: ch = 'S'; break;
                case 29: ch = 'T'; break;
                case 30: ch = 'U'; break;
                case 31: ch = 'V'; break;
                case 32: ch = 'W'; break;
                case 33: ch = 'X'; break;
                case 34: ch = 'Y'; break;
                case 35: ch = 'Z'; break;
                case 36: ch = ' '; break;
                case 37: ch = '.'; break;
                case 38: ch = '='; break;
                case 39: ch = ','; break;
                case 40: ch = '*'; break;
                case 41: ch = '\\'; break;
                case 42: ch = '-'; break;
                case 43: ch = '/'; break;
                default: ch = ' '; break;
            }
            return ch;
        }
        #endregion

        #endregion

        #region converte string para data
        public DateTime StringToDate(string data)
        {
            DateTime newDate;

            if (data.Length == 12)
            {
                try
                {
                    int ano = Convert.ToInt16(data.Substring(0, 2)) + 2000;
                    int mes = Convert.ToInt16(data.Substring(2, 2));
                    int dia = Convert.ToInt16(data.Substring(4, 2));
                    int hora = Convert.ToInt16(data.Substring(6, 2));
                    int minuto = Convert.ToInt16(data.Substring(8, 2));
                    int segundo = Convert.ToInt16(data.Substring(10, 2));
                    newDate = new DateTime(ano, mes, dia, hora, minuto, segundo);
                }
                catch
                {
                    newDate = DateTime.Now;
                }
            }
            else
            {
                try
                {
                    int ano = DateTime.Now.Year;
                    int mes = Convert.ToInt16(data.Substring(0, 2));
                    int dia = Convert.ToInt16(data.Substring(2, 2));
                    int hora = Convert.ToInt16(data.Substring(4, 2));
                    int minuto = Convert.ToInt16(data.Substring(6, 2));
                    int segundo = Convert.ToInt16(data.Substring(8, 2));
                    newDate = new DateTime(ano, mes, dia, hora, minuto, segundo);
                }
                catch
                {
                    newDate = DateTime.Now;
                }
            }

            return newDate;
        }
        #endregion

        #region binary to hex / hex to binary
        public byte[] BinaryToHexArray(string stringBinary)
        {
            byte[] arrayRetorno = new byte[stringBinary.Length / 8];

            int indice = 0;
            for (int i = 0; i < stringBinary.Length; i += 8)
            {
                arrayRetorno[indice] = Convert.ToByte(stringBinary.Substring(i, 8), 2);
                indice++;
            }
            return arrayRetorno;
        }

        public string BinaryToHex(string stringBinary)
        {
            StringBuilder result = new StringBuilder(stringBinary.Length / 8 + 1);
            int mod4Len = stringBinary.Length % 8;
            if (mod4Len != 0)
            {
                stringBinary = stringBinary.PadLeft(((stringBinary.Length / 8) + 1) * 8, '0');
            }

            for (int i = 0; i < stringBinary.Length; i += 8)
            {
                string eightBits = stringBinary.Substring(i, 8);
                result.AppendFormat("{0:X2}", Convert.ToByte(eightBits, 2));
            }
            return result.ToString();
        }

        public string HexToBinary(string data)
        {
            return String.Join(String.Empty, data.Select(c => Convert.ToString(Convert.ToInt32(c.ToString(), 16), 2).PadLeft(4, '0')));
        }

        public int[] BinaryInvert(string data)
        {
            int[] bits = Array.ConvertAll(data.ToCharArray(), c => (int)Char.GetNumericValue(c));
            Array.Reverse(bits);
            return bits;
        }
        #endregion

        #region string to byte array / byte array to string
        public byte[] StringToByteArrayBase16(string hex)
        {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
            return bytes;
        }

        public byte[] StringToByteArrayBase8(string hex)
        {
            int NumberChars = hex.Length;
            byte[] bytes = new byte[NumberChars / 2];
            for (int i = 0; i < NumberChars; i += 2)
                bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 8);
            return bytes;
        }

        public byte[] StringToByteArray(string str)
        {
            Dictionary<string, byte> hexindex = new Dictionary<string, byte>();
            for (int i = 0; i <= 255; i++)
                hexindex.Add(i.ToString("X2"), (byte)i);

            List<byte> hexres = new List<byte>();
            for (int i = 0; i < str.Length; i += 2)
                hexres.Add(hexindex[str.Substring(i, 2)]);

            return hexres.ToArray();
        }

        public string ByteArrayToString(byte[] ba)
        {
            string hex = BitConverter.ToString(ba);
            return hex.Replace("-", "");
        }

        public string ByteArrayToString(byte[] ba, int p1)
        {
            string hex = BitConverter.ToString(ba, p1);
            return hex.Replace("-", "");
        }

        public string ByteArrayToString(byte[] ba, int p1, int p2)
        {
            string hex = BitConverter.ToString(ba, p1, p2);
            return hex.Replace("-", "");
        }
        #endregion

        #region hex to ascii / ascii to hex
        public byte[] HexStringToHexArray(string ascii)
        {
            byte[] arrayRetorno = new byte[ascii.Length / 2];

            int indice = 0;
            for (int i = 0; i < ascii.Length; i += 2)
            {
                arrayRetorno[indice] = byte.Parse(ascii.Substring(i, 2));
                indice++;
            }
            return arrayRetorno;
        }

        public string HexToAscii(string hexString)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hexString.Length; i += 2)
            {
                sb.Append(Convert.ToString(Convert.ToChar(Int32.Parse(hexString.Substring(i, 2), System.Globalization.NumberStyles.HexNumber))));
            }
            return sb.ToString();
        }

        public string AsciiToHex(string ascii)
        {
            return ByteArrayToString(Encoding.ASCII.GetBytes(ascii));
        }

        public byte[] AsciiToHexArray(string ascii)
        {
            byte[] arrayRetorno = new byte[ascii.Length / 2];

            int indice = 0;
            for (int i = 0; i < ascii.Length; i += 2)
            {
                arrayRetorno[indice] = Convert.ToByte(ascii.Substring(i, 2), 16);
                indice++;
            }
            return arrayRetorno;
        }
        #endregion

        #region hex to decimal / decimal to hex
        public int HexToDecimal(string hex)
        {
            int returnVal = 0;
            int intCtr = 0;
            bool bolTrue = false;

            if (hex.Substring(0, 1) == "0")
            {
                hex = hex.Substring(0, 1) == "0" ? hex.Substring(1, 1) : hex.Substring(0, 1);
            }

            while (!bolTrue)
            {
                if (hex == intCtr.ToString("X"))
                {
                    returnVal = intCtr;
                    bolTrue = true;
                }
                intCtr++;
            }

            return returnVal;
        }

        public string DecimalToHex(int decimalString)
        {
            return decimalString.ToString("X2");
        }

        public string DecimalToHex(byte[] arr)
        {
            return BitConverter.ToString(arr).Replace("-", string.Empty);
        }
        #endregion

        #region ebcdic to ascii / ascii to ebcdic
        public byte[] AsciiToEbcDic(string asciiString)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            return Encoding.GetEncoding("IBM037").GetBytes(asciiString);
        }

        public string EbcDicToAscii(byte[] ebcdicArray)
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            return Encoding.GetEncoding("IBM037").GetString(ebcdicArray);
        }
        #endregion

        #region base 64 and jwt spec
        private byte[] FromBase64Url(string base64Url)
        {
            string padded = base64Url.Length % 4 == 0 ? base64Url : base64Url + "====".Substring(base64Url.Length % 4);
            string base64 = padded.Replace("_", "/").Replace("-", "+");
            return Convert.FromBase64String(base64);
        }

        // from JWT spec
        public byte[] Base64UrlDecode(string input)
        {
            var output = input;
            output = output.Replace('-', '+'); // 62nd char of encoding  
            output = output.Replace('_', '/'); // 63rd char of encoding  
            switch (output.Length % 4) // Pad with trailing '='s  
            {
                case 0: break; // No pad chars in this case  
                case 2: output += "=="; break; // Two pad chars  
                case 3: output += "="; break; // One pad char  
                default: throw new System.Exception("Invalid Base64URL String");
            }
            var converted = Convert.FromBase64String(output); // Standard base64 decoder  
            return converted;
        }

        public string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }
        #endregion

    }
}
