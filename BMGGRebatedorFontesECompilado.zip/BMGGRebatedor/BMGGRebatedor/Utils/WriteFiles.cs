﻿using System;
using System.IO;
using System.Text;

namespace BMGGRebatedor.Utils
{
    public sealed class WriteFiles
    {
        string path = string.Empty;
        string pathTemp = string.Empty;
        string nomeArquivo = string.Empty;
        string nomeArquivoTemp = string.Empty;

        #region construtor
        public WriteFiles(string pastaTemp, string pasta, string arquivo)
        {
            nomeArquivo = arquivo;
            nomeArquivoTemp = string.Format("{0}{1:yyyyMMdd}", arquivo, DateTime.Now);

            if (!Directory.Exists(pasta))
                Directory.CreateDirectory(pasta);

            if (!Directory.Exists(pastaTemp))
                Directory.CreateDirectory(pastaTemp);

            path = string.Format("{0}.txt", Path.Combine(pasta, nomeArquivo));
            pathTemp = string.Format("{0}.txt", Path.Combine(pastaTemp, nomeArquivoTemp));
        }
        #endregion

        #region escrever no arquivo
        public void WriteData(string data, bool newLine)
        {
            Encoding utf8WithoutBom = new UTF8Encoding(false);
            using (TextWriter writer = new StreamWriter(pathTemp, true, utf8WithoutBom))
            {
                writer.NewLine = "\n";
                if (newLine)
                    writer.WriteLine(data, Encoding.ASCII);
                else
                    writer.Write(data, Encoding.ASCII);
                writer.Flush();
            }
        }
        #endregion

        #region copiar arquivo para a pasta do connect direct
        public void CopyFile(string nomeArquivo)
        {
            if (File.Exists(pathTemp))
            {
                File.Copy(pathTemp, path, true);
            }
        }
        #endregion

    }
}
