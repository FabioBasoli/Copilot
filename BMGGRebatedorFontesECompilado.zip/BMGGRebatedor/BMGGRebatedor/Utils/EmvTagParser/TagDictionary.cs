﻿using System.Collections.Generic;

namespace BMGGRebatedor.Utils.EmvTagParser
{
    public sealed class TagDictionary
    {

        #region singleton
        public static List<TagEmvModel> lstTags;

        private static TagDictionary instance = null;
        private static readonly object syncTags = new object();

        TagDictionary() { }

        public static TagDictionary Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (syncTags)
                    {
                        if (instance == null)
                        {
                            instance = new TagDictionary();
                            lstTags = new List<TagEmvModel>();
                            GegeneratesTagsList();
                        }
                    }
                }
                return instance;
            }
        }
        #endregion

        #region lista de tags
        private static void GegeneratesTagsList()
        {
            lstTags.Add(new TagEmvModel("", "90", "Issuer Public Key Certificate"));
            lstTags.Add(new TagEmvModel("BF0C", "42", "Issuer Identification Number (IIN)"));
            lstTags.Add(new TagEmvModel("73", "42", "Issuer Identification Number (IIN)"));
            lstTags.Add(new TagEmvModel("61", "4F", "Application Identifier (AID)"));
            lstTags.Add(new TagEmvModel("61", "50", "Application Label"));
            lstTags.Add(new TagEmvModel("A5", "50", "Application Label"));
            lstTags.Add(new TagEmvModel("70", "57", "Track 2 Equivalent Data"));
            lstTags.Add(new TagEmvModel("77", "57", "Track 2 Equivalent Data"));
            lstTags.Add(new TagEmvModel("70", "5A", "Application Primary Account Number (PAN)"));
            lstTags.Add(new TagEmvModel("77", "5A", "Application Primary Account Number (PAN)"));
            lstTags.Add(new TagEmvModel("70", "5F20", "Cardholder Name"));
            lstTags.Add(new TagEmvModel("77", "5F20", "Cardholder Name"));
            lstTags.Add(new TagEmvModel("70", "5F24", "Application Expiration Date", "03"));
            lstTags.Add(new TagEmvModel("77", "5F24", "Application Expiration Date", "03"));
            lstTags.Add(new TagEmvModel("70", "5F25", "Application Effective Date", "03"));
            lstTags.Add(new TagEmvModel("77", "5F25", "Application Effective Date", "03"));
            lstTags.Add(new TagEmvModel("70", "5F28", "Issuer Country Code", "02"));
            lstTags.Add(new TagEmvModel("77", "5F28", "Issuer Country Code", "02"));
            lstTags.Add(new TagEmvModel("", "5F2A", "Transaction Currency Code", "02"));
            lstTags.Add(new TagEmvModel("A5", "5F2D", "Language Preference"));
            lstTags.Add(new TagEmvModel("70", "5F30", "Service Code", "02"));
            lstTags.Add(new TagEmvModel("77", "5F30", "Service Code", "02"));
            lstTags.Add(new TagEmvModel("70", "5F34", "Application Primary Account Number (PAN)Sequence Number", "01"));
            lstTags.Add(new TagEmvModel("77", "5F34", "Application Primary Account Number (PAN)Sequence Number", "01"));
            lstTags.Add(new TagEmvModel("", "5F36", "Transaction Currency Exponent", "01"));
            lstTags.Add(new TagEmvModel("BF0C", "5F50", "Issuer URL"));
            lstTags.Add(new TagEmvModel("73", "5F50", "Issuer URL"));
            lstTags.Add(new TagEmvModel("BF0C", "5F53", "International Bank Account Number (IBAN)"));
            lstTags.Add(new TagEmvModel("73", "5F53", "International Bank Account Number (IBAN)"));
            lstTags.Add(new TagEmvModel("BF0C", "5F54", "Bank Identifier Code (BIC)"));
            lstTags.Add(new TagEmvModel("73", "5F54", "Bank Identifier Code (BIC)"));
            lstTags.Add(new TagEmvModel("BF0C", "5F55", "Issuer Country Code (alpha2 format)", "01"));
            lstTags.Add(new TagEmvModel("73", "5F55", "Issuer Country Code (alpha2 format)", "01"));
            lstTags.Add(new TagEmvModel("70", "61", "Application Template"));
            lstTags.Add(new TagEmvModel("77", "61", "Application Template"));
            lstTags.Add(new TagEmvModel("", "6F", "File Control Information (FCI) Template"));
            lstTags.Add(new TagEmvModel("", "6F", "File Control Information (FCI) Template"));
            lstTags.Add(new TagEmvModel("", "71", "Issuer Script Template 1"));
            lstTags.Add(new TagEmvModel("", "72", "Issuer Script Template 2"));
            lstTags.Add(new TagEmvModel("61", "73", "Directory Discretionary Template"));
            lstTags.Add(new TagEmvModel("", "77", "Response Message Template Format 2"));
            lstTags.Add(new TagEmvModel("", "80", "Response Message Template Format 1"));
            lstTags.Add(new TagEmvModel("", "70", "Read Record Response Message"));
            lstTags.Add(new TagEmvModel("", "81", "Amount, Authorised (Binary)", "04"));
            lstTags.Add(new TagEmvModel("77", "82", "Application Interchange Profile", "02"));
            lstTags.Add(new TagEmvModel("80", "82", "Application Interchange Profile", "02"));
            lstTags.Add(new TagEmvModel("", "83", "Command Template"));
            lstTags.Add(new TagEmvModel("6F", "84", "Dedicated File (DF) Name"));
            lstTags.Add(new TagEmvModel("71", "86", "Issuer Script Command"));
            lstTags.Add(new TagEmvModel("72", "86", "Issuer Script Command"));
            lstTags.Add(new TagEmvModel("61", "87", "Application Priority Indicator", "01"));
            lstTags.Add(new TagEmvModel("A5", "87", "Application Priority Indicator", "01"));
            lstTags.Add(new TagEmvModel("A5", "88", "Short File Identifier (SFI)", "01"));
            lstTags.Add(new TagEmvModel("", "89", "Authorisation Code", "06"));
            lstTags.Add(new TagEmvModel("", "8A", "Authorisation Response Code", "02"));
            lstTags.Add(new TagEmvModel("70", "8C", "Card Risk Management Data Object List 1 (CDOL1)"));
            lstTags.Add(new TagEmvModel("77", "8C", "Card Risk Management Data Object List 1 (CDOL1)"));
            lstTags.Add(new TagEmvModel("70", "8D", "Card Risk Management Data Object List 2 (CDOL2)"));
            lstTags.Add(new TagEmvModel("77", "8D", "Card Risk Management Data Object List 2 (CDOL2)"));
            lstTags.Add(new TagEmvModel("70", "8E", "Cardholder Verification Method (CVM) List"));
            lstTags.Add(new TagEmvModel("77", "8E", "Cardholder Verification Method (CVM) List"));
            lstTags.Add(new TagEmvModel("70", "8F", "Certification Authority Public Key Index", "01"));
            lstTags.Add(new TagEmvModel("77", "8F", "Certification Authority Public Key Index", "01"));
            //lstTags.Add(new TagEmv("70","90","Issuer Public Key Certificate"));
            //lstTags.Add(new TagEmv("77","90","Issuer Public Key Certificate"));
            lstTags.Add(new TagEmvModel("", "91", "Issuer Authentication Data"));
            lstTags.Add(new TagEmvModel("70", "92", "Issuer Public Key Remainder"));
            lstTags.Add(new TagEmvModel("77", "92", "Issuer Public Key Remainder"));
            lstTags.Add(new TagEmvModel("70", "93", "Signed Static Application Data"));
            lstTags.Add(new TagEmvModel("77", "93", "Signed Static Application Data"));
            lstTags.Add(new TagEmvModel("77", "94", "Application File Locator (AFL)"));
            lstTags.Add(new TagEmvModel("80", "94", "Application File Locator (AFL)"));
            lstTags.Add(new TagEmvModel("", "95", "Terminal Verification Results", "05"));
            lstTags.Add(new TagEmvModel("70", "97", "Transaction Certificate Data Object List (TDOL)"));
            lstTags.Add(new TagEmvModel("77", "97", "Transaction Certificate Data Object List (TDOL)"));
            lstTags.Add(new TagEmvModel("", "98", "Transaction Certificate (TC) Hash Value", "14"));
            lstTags.Add(new TagEmvModel("", "99", "Transaction Personal Identification Number (PIN)Data"));
            lstTags.Add(new TagEmvModel("", "9A", "Transaction Date", "03"));
            lstTags.Add(new TagEmvModel("", "9B", "Transaction Status Information", "02"));
            lstTags.Add(new TagEmvModel("", "9C", "Transaction Type", "01"));
            lstTags.Add(new TagEmvModel("61", "9D", "Directory Definition File (DDF) Name"));
            lstTags.Add(new TagEmvModel("", "9F01", "Acquirer Identifier", "06"));
            lstTags.Add(new TagEmvModel("", "9F02", "Amount, Authorised (Numeric)", "06"));
            lstTags.Add(new TagEmvModel("", "9F03", "Amount, Other (Numeric)", "06"));
            lstTags.Add(new TagEmvModel("", "9F04", "Amount, Other (Binary)", "04"));
            lstTags.Add(new TagEmvModel("70", "9F05", "Application Discretionary Data"));
            lstTags.Add(new TagEmvModel("77", "9F05", "Application Discretionary Data"));
            lstTags.Add(new TagEmvModel("", "9F06", "Application Identifier (AID) - terminal"));
            lstTags.Add(new TagEmvModel("70", "9F07", "Application Usage Control", "02"));
            lstTags.Add(new TagEmvModel("77", "9F07", "Application Usage Control", "02"));
            lstTags.Add(new TagEmvModel("70", "9F08", "Application Version Number", "02"));
            lstTags.Add(new TagEmvModel("77", "9F08", "Application Version Number", "02"));
            lstTags.Add(new TagEmvModel("", "9F09", "Application Version Number", "02"));
            lstTags.Add(new TagEmvModel("70", "9F0B", "Cardholder Name Extended"));
            lstTags.Add(new TagEmvModel("77", "9F0B", "Cardholder Name Extended"));
            lstTags.Add(new TagEmvModel("70", "9F0D", "Issuer Action Code - Default", "05"));
            lstTags.Add(new TagEmvModel("77", "9F0D", "Issuer Action Code - Default", "05"));
            lstTags.Add(new TagEmvModel("70", "9F0E", "Issuer Action Code - Denial", "05"));
            lstTags.Add(new TagEmvModel("77", "9F0E", "Issuer Action Code - Denial", "05"));
            lstTags.Add(new TagEmvModel("70", "9F0F", "Issuer Action Code - Online", "05"));
            lstTags.Add(new TagEmvModel("77", "9F0F", "Issuer Action Code - Online", "05"));
            lstTags.Add(new TagEmvModel("77", "9F10", "Issuer Application Data"));
            lstTags.Add(new TagEmvModel("80", "9F10", "Issuer Application Data"));
            lstTags.Add(new TagEmvModel("A5", "9F11", "Issuer Code Table Index", "01"));
            lstTags.Add(new TagEmvModel("61", "9F12", "Application Preferred Name"));
            lstTags.Add(new TagEmvModel("A5", "9F12", "Application Preferred Name"));
            lstTags.Add(new TagEmvModel("", "9F13", "Last Online Application Transaction Counter (ATC) Register", "02"));
            lstTags.Add(new TagEmvModel("70", "9F14", "Lower Consecutive Offline Limit", "01"));
            lstTags.Add(new TagEmvModel("77", "9F14", "Lower Consecutive Offline Limit", "01"));
            lstTags.Add(new TagEmvModel("", "9F15", "Merchant Category Code", "02"));
            lstTags.Add(new TagEmvModel("", "9F16", "Merchant Identifier", "15"));
            lstTags.Add(new TagEmvModel("", "9F17", "Personal Identification Number (PIN) Try Counter", "01"));
            lstTags.Add(new TagEmvModel("71", "9F18", "Issuer Script Identifier", "04"));
            lstTags.Add(new TagEmvModel("72", "9F18", "Issuer Script Identifier", "04"));
            lstTags.Add(new TagEmvModel("", "9F1A", "Terminal Country Code", "02"));
            lstTags.Add(new TagEmvModel("", "9F1B", "Terminal Floor Limit", "04"));
            lstTags.Add(new TagEmvModel("", "9F1C", "Terminal Identification", "08"));
            lstTags.Add(new TagEmvModel("", "9F1D", "Terminal Risk Management Data"));
            lstTags.Add(new TagEmvModel("", "9F1E", "Interface Device (IFD) Serial Number"));
            lstTags.Add(new TagEmvModel("70", "9F1F", "Track 1 Discretionary Data"));
            lstTags.Add(new TagEmvModel("77", "9F1F", "Track 1 Discretionary Data"));
            lstTags.Add(new TagEmvModel("70", "9F20", "Track 2 Discretionary Data"));
            lstTags.Add(new TagEmvModel("77", "9F20", "Track 2 Discretionary Data"));
            lstTags.Add(new TagEmvModel("", "9F21", "Transaction Time", "03"));
            lstTags.Add(new TagEmvModel("", "9F22", "Certification Authority Public Key Index", "01"));
            lstTags.Add(new TagEmvModel("70", "9F23", "Upper Consecutive Offline Limit", "01"));
            lstTags.Add(new TagEmvModel("77", "9F23", "Upper Consecutive Offline Limit", "01"));
            lstTags.Add(new TagEmvModel("77", "9F26", "Application Cryptogram", "08"));
            lstTags.Add(new TagEmvModel("80", "9F26", "Application Cryptogram", "08"));
            lstTags.Add(new TagEmvModel("77", "9F27", "Cryptogram Information Data", "01"));
            lstTags.Add(new TagEmvModel("80", "9F27", "Cryptogram Information Data", "01"));
            lstTags.Add(new TagEmvModel("70", "9F2D", "ICC PIN Encipherment Public Key Certificate"));
            lstTags.Add(new TagEmvModel("77", "9F2D", "ICC PIN Encipherment Public Key Certificate"));
            lstTags.Add(new TagEmvModel("70", "9F2E", "ICC PIN Encipherment Public Key Exponent"));
            lstTags.Add(new TagEmvModel("77", "9F2E", "ICC PIN Encipherment Public Key Exponent"));
            lstTags.Add(new TagEmvModel("70", "9F2F", "ICC PIN Encipherment Public Key Remainder"));
            lstTags.Add(new TagEmvModel("77", "9F2F", "ICC PIN Encipherment Public Key Remainder"));
            lstTags.Add(new TagEmvModel("70", "9F32", "Issuer Public Key Exponent"));
            lstTags.Add(new TagEmvModel("77", "9F32", "Issuer Public Key Exponent"));
            lstTags.Add(new TagEmvModel("", "9F33", "Terminal Capabilities", "03"));
            lstTags.Add(new TagEmvModel("", "9F34", "Cardholder Verification Method (CVM) Results", "03"));
            lstTags.Add(new TagEmvModel("", "9F35", "Terminal Type", "01"));
            lstTags.Add(new TagEmvModel("77", "9F36", "Application Transaction Counter (ATC)", "02"));
            lstTags.Add(new TagEmvModel("80", "9F36", "Application Transaction Counter (ATC)", "02"));
            lstTags.Add(new TagEmvModel("", "9F37", "Unpredictable Number", "04"));
            lstTags.Add(new TagEmvModel("A5", "9F38", "Processing Options Data Object List (PDOL)"));
            lstTags.Add(new TagEmvModel("", "9F39", "Point-of-Service (POS) Entry Mode", "01"));
            lstTags.Add(new TagEmvModel("", "9F3A", "Amount, Reference Currency", "04"));
            lstTags.Add(new TagEmvModel("70", "9F3B", "Application Reference Currency"));
            lstTags.Add(new TagEmvModel("77", "9F3B", "Application Reference Currency"));
            lstTags.Add(new TagEmvModel("", "9F3C", "Transaction Reference Currency Code", "02"));
            lstTags.Add(new TagEmvModel("", "9F3D", "Transaction Reference Currency Exponent", "01"));
            lstTags.Add(new TagEmvModel("", "9F40", "Additional Terminal Capabilities", "40"));
            lstTags.Add(new TagEmvModel("", "9F41", "Transaction Sequence Counter"));
            lstTags.Add(new TagEmvModel("70", "9F42", "Application Currency Code", "02"));
            lstTags.Add(new TagEmvModel("77", "9F42", "Application Currency Code", "02"));
            lstTags.Add(new TagEmvModel("70", "9F43", "Application Reference Currency Exponent"));
            lstTags.Add(new TagEmvModel("77", "9F43", "Application Reference Currency Exponent"));
            lstTags.Add(new TagEmvModel("70", "9F44", "Application Currency Exponent", "01"));
            lstTags.Add(new TagEmvModel("77", "9F44", "Application Currency Exponent", "01"));
            lstTags.Add(new TagEmvModel("", "9F45", "Data Authentication Code", "02"));
            lstTags.Add(new TagEmvModel("70", "9F46", "ICC Public Key Certificate"));
            lstTags.Add(new TagEmvModel("77", "9F46", "ICC Public Key Certificate"));
            lstTags.Add(new TagEmvModel("70", "9F47", "ICC Public Key Exponent"));
            lstTags.Add(new TagEmvModel("77", "9F47", "ICC Public Key Exponent"));
            lstTags.Add(new TagEmvModel("70", "9F48", "ICC Public Key Remainder"));
            lstTags.Add(new TagEmvModel("77", "9F48", "ICC Public Key Remainder"));
            lstTags.Add(new TagEmvModel("70", "9F49", "Dynamic Data Authentication Data Object List(DDOL)"));
            lstTags.Add(new TagEmvModel("77", "9F49", "Dynamic Data Authentication Data Object List(DDOL)"));
            lstTags.Add(new TagEmvModel("70", "9F4A", "Static Data Authentication Tag List"));
            lstTags.Add(new TagEmvModel("77", "9F4A", "Static Data Authentication Tag List"));
            lstTags.Add(new TagEmvModel("", "9F4B", "Signed Dynamic Application Data"));
            lstTags.Add(new TagEmvModel("", "9F4C", "ICC Dynamic Number"));
            lstTags.Add(new TagEmvModel("BF0C", "9F4D", "Log Entry", "02"));
            lstTags.Add(new TagEmvModel("73", "9F4D", "Log Entry", "02"));
            lstTags.Add(new TagEmvModel("", "9F4E", "Merchant Name and Location"));
            lstTags.Add(new TagEmvModel("", "9F4F", "Log Format"));
            lstTags.Add(new TagEmvModel("6F", "A5", "File Control Information (FCI) Proprietary Template"));
            lstTags.Add(new TagEmvModel("A5", "BF0C", "File Control Information (FCI) Issuer Discretionary Data"));
        }
        #endregion

    }
}
