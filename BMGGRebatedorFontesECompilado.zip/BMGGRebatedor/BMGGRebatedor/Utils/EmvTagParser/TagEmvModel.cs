﻿namespace BMGGRebatedor.Utils.EmvTagParser
{
    public class TagEmvModel
    {
        public string Template { get; private set; }
        public string Tag { get; private set; }
        public string Name { get; private set; }
        public string Length { get; private set; }

        public TagEmvModel(string template, string tag, string name)
        {
            this.Template = template;
            this.Tag = tag;
            this.Name = name;
        }

        public TagEmvModel(string template, string tag, string name, string length)
        {
            this.Template = template;
            this.Tag = tag;
            this.Name = name;
            this.Length = length;
        }

    }
}
