﻿using System.Linq;
using BMGGRebatedor.BMGGLog;
using System.Collections.Generic;

namespace BMGGRebatedor.Utils.EmvTagParser
{
    public class TagParser
    {
        LogManagement log;

        #region construtor
        public TagParser(LogManagement log)
        {
            this.log = log;
        }
        #endregion

        #region parser
        public List<TagEmvParsed> Parser(List<TagEmvParsed> lstTags, string tagsEmv)
        {
            if (string.IsNullOrEmpty(tagsEmv))
            {
                log.LogInformation("Bit 55 está vazio, processamento de tags não realizado");
                return null;
            }
            else
            {
                if (lstTags == null) lstTags = new List<TagEmvParsed>();

                TagDictionary tags = TagDictionary.Instance;

                Converters converter = new Converters();

                int position = 0;
                int length = 0;
                string tag = string.Empty;
                string value = string.Empty;

                while (position < tagsEmv.Length)
                {
                    tag = tagsEmv.Substring(position, 2);
                    position += 2;
                    int[] binary = converter.BinaryInvert(converter.HexToBinary(tag));
                    int bit = int.Parse(tag, System.Globalization.NumberStyles.HexNumber);

                    if ((bit & 0x1F) >= 31)
                    {
                        tag += tagsEmv.Substring(position, 2);
                        position += 2;
                    }

                    length = converter.HexToDecimal(tagsEmv.Substring(position, 2)) * 2;
                    position += 2;

                    value = tagsEmv.Substring(position, length);
                    position += length;

                    string name = TagDictionary.lstTags.Where(x => x.Tag.Equals(tag)).Select(x => x.Name).FirstOrDefault();
                    name = name != null ? name : string.Empty;
                    lstTags.Add(new TagEmvParsed(tag, name, length.ToString(), value));

                    log.LogAdvanced($"{name} - [{tag}] - [{value.Length}]: {value}");
                }

                return lstTags;
            }
        }
        #endregion

    }
}
