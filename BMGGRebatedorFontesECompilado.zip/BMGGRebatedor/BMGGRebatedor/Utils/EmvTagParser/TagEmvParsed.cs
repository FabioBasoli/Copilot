﻿namespace BMGGRebatedor.Utils.EmvTagParser
{
    public class TagEmvParsed : TagEmvModel
    {
        public string value { get; set; }

        public TagEmvParsed(string tag, string name, string length, string valor, string template = "") : base(template, tag, name, length)
        {
            this.value = valor;
        }
    }
}
