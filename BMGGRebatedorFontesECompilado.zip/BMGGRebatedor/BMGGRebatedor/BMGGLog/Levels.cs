namespace BMGGRebatedor.BMGGLog
{
    public enum Levels
    {
        ERRO = 1,
        INFO = 2,
        ADVN = 3,
        FULL = 4
    }
}