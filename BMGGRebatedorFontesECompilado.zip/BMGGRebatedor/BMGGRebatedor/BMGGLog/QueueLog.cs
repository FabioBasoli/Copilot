using System;
using System.IO;
using System.Threading;
using System.Collections.Generic;

namespace BMGGRebatedor.BMGGLog
{
    public static class QueueLog
    {
        static readonly object syncLog = new object();

        static List<LogModel> lstQueueLog { get; set; }

        #region instantiate
        public static void Instantiate()
        {
            lstQueueLog = new List<LogModel>();
            Thread threadLog = new Thread(Remove);
            threadLog.IsBackground = true;
            threadLog.Start();
        }
        #endregion

        #region adiciona log a fila
        public static void Add(LogModel data)
        {
            lock (syncLog)
            {
                lstQueueLog.Add(data);
                Thread.Sleep(10);
            }
        }
        #endregion

        #region grava log e remove da fila
        private static void Remove()
        {
            while (true)
            {
                try
                {
                    lock (syncLog)
                    {
                        if (lstQueueLog.Count > 0)
                        {
                            LogModel log = lstQueueLog[0];

                            using (StreamWriter writer = File.AppendText(log.path))
                            {
                                if (!string.IsNullOrEmpty(log.message))
                                {
                                    writer.WriteLine($"{DateTime.Now:dd/MM/yy HH:mm:ss.fff}-[{log.level}]-{log.message}");
                                    writer.Flush();
                                }
                                else
                                {
                                    for (int i = 0; i < log.messageArray.Length; i++)
                                    {
                                        if (log.messageArray[i] != null)
                                            writer.WriteLine($"{DateTime.Now:dd/MM/yy HH:mm:ss.fff}-[{log.level}]\t[bit {i:000}] {log.messageArray[i]}");
                                    }
                                    writer.Flush();
                                }
                            }
                            lstQueueLog.Remove(log);
                        }
                    }
                }
                catch { }
                Thread.Sleep(10);
            }
        }
        #endregion

    }
}