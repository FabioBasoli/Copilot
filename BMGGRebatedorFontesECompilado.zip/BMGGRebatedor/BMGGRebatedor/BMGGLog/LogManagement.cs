using System;
using System.IO;
using System.Collections.Generic;

namespace BMGGRebatedor.BMGGLog
{
    public class LogManagement : LogBase
    {
        public string path { get; set; }
        public Levels level { get; set; }

        #region contrutor
        public LogManagement(string path, string file, Levels level)
        {
            var data = DateTime.Now.ToString("dd-MM-yyyy");
            var dirExecutavel = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            this.path = Path.Combine(dirExecutavel, "LOGS", path, data, $"{file}.txt");
            this.level = level;
            
            var directory = Path.Combine(dirExecutavel, "LOGS", path, data);
            if (!Directory.Exists(directory)) Directory.CreateDirectory(directory);
            if (!File.Exists(this.path)) File.Create(this.path).Dispose();
        }
        #endregion

        #region loggers
        public void LogError(string message)
        {
            Log(message, Levels.ERRO);
        }

        public void LogInformation(string message)
        {
            Log(message, Levels.INFO);
        }

        public void LogAdvanced(string message)
        {
            Log(message, Levels.ADVN);
        }

        public void LogFull(string message)
        {
            Log(message, Levels.FULL);
        }

        private void Log(string message, Levels level)
        {
            if (level <= this.level)
            {
                string data = string.Format("{0:dd-MM-yyyy}", DateTime.Now);
                QueueLog.Add(new LogModel(path, message, data, level));
            }
        }
        #endregion
        
    }
}