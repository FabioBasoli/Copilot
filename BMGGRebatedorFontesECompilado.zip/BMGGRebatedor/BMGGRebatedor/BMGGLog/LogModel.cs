namespace BMGGRebatedor.BMGGLog
{
    public sealed class LogModel
    {
        public string path { get; set; }
        public string[] messageArray { get; set; }
        public string message { get; set; }
        public string data { get; set; }
        public Levels level { get; set; }

        public LogModel(string path, string message, string data, Levels level)
        {
            this.path = path;
            this.message = message;
            this.data = data;
            this.level = level;
        }

        public LogModel(string path, string[] message, string data, Levels level)
        {
            this.path = path;
            this.messageArray = message;
            this.data = data;
            this.level = level;
        }
    }
}