using System;
using System.Linq;
using System.Collections.Generic;
using System.Net.Cache;
using BMGGRebatedor.BMGGIso.Parser;

namespace BMGGRebatedor.BMGGIso.Rebut
{
    public class ToRebut
    {
        byte[] array;
        string rede;

        IParserIso parser;

        #region construtor
        public ToRebut(byte[] array, string rede)
        {
            this.array = array;
            this.rede = rede;
        }
        #endregion

        #region tratar mensagem
        public List<byte> Proccess()
        {
            int sizeHeader = Headertype();

            if (array.Length < 100) return array.ToList();
            
            ISOMessage iso = null;
            switch (rede)
            {
                case "02": iso = new ISOMessage(ISOMessageHeader.BIGASCIIVISA); break;
                case "03": iso = new ISOMessage(ISOMessageHeader.BIGASCII); break;
                case "04": iso = new ISOMessage(ISOMessageHeader.BIGASCIITPDU); break;
                default: iso = new ISOMessage(ISOMessageHeader.BIGASCII); break;
            }

            iso.PacketRecByte = array;
            var arrayRecebido = parser.ReadIso(iso.PacketRecByte).ToList();

            arrayRecebido[0] = string.Empty;
            arrayRecebido[1] = string.Empty;
            arrayRecebido[38] = new Random().Next(100000, 999999).ToString();
            arrayRecebido[39] = "00";

            string mti = arrayRecebido[129] ?? arrayRecebido[195];
            switch (mti)
            {
                case "0200": mti = "0210"; break;
                case "0220": mti = "0230"; break;
                case "0400": mti = "0410"; break;
                case "0420": mti = "0430"; break;
                case "9820": mti = "9830"; break;
                case "0100": mti = "0110"; break;
            }

            List<ModelBit> DE = new List<ModelBit>();
            DE = new DataElements().GetDataElements(rede);
            Builder build = new Builder(DE);
            
            /* RETORNO DE UMA MENSAGEM */
            byte[] arrayRetorno = null;
            switch (rede)
            {
                case "02":
                    var arrayStringVisa = arrayRecebido.ToArray();
                    byte[][] arrayVisa = new byte[200][];
                    
                    for (int i = 0; i < arrayStringVisa.Length; i++)
                    {
                        if (i < 160)
                            if (!string.IsNullOrEmpty(arrayStringVisa[i]))
                                build.CriaBit(ref arrayVisa, i, arrayStringVisa[i]);
                    }
                    arrayRetorno = AddHeaderSizeVisa(build.Build(arrayVisa.ToArray(), mti));
                    break;
                case "03":
                    arrayRetorno = AddHeaderSize(build.BuildMaster(arrayRecebido.ToArray(), mti));
                    break;
                case "04":
                    int[] hexa = new int[] {52, 55};
                    string[] arrayElo = new string[130];
                    var arrayStringElo = arrayRecebido.ToArray();

                    arrayStringElo[52] = string.Empty;
                    arrayStringElo[53] = string.Empty;
                    arrayStringElo[58] = string.Empty;
                    
                    for (int i = 0; i < arrayStringElo.Length; i++)
                    {
                        if (!string.IsNullOrEmpty(arrayStringElo[i]))
                            build.CriaBit(ref arrayElo, i, arrayStringElo[i]);
                    }
                    arrayRetorno = AddHeaderSizeElo(build.Build(arrayElo.ToArray(), mti, hexa));
                    break;
                case "07":
                    arrayRetorno = AddHeaderSize(build.Build(arrayRecebido.ToArray(), mti, DE));
                    break;
                case "08":
                    arrayRetorno = AddHeaderSize(build.Build(arrayRecebido.ToArray(), mti, DE));
                    break;
            }
            

            /* RETORNO DE DUAS MENSAGENS 
            var ret1 = AddHeaderSize(build.Build(arrayRecebido.ToArray(), mti, DE));
            var ret3 = build.Build(arrayRecebido.ToArray(), mti, DE);
            var ret2 = AddHeaderSize(ret3.Concat(new byte[4] {10, 11, 12, 13}).ToArray());
            //var ret2 = AddHeaderSize(build.Build(arrayRecebido.ToArray(), mti, DE));
            var arrayRetorno = ret1.Concat(ret2);
            */
            
            return arrayRetorno.ToList();
        }
        #endregion

        #region tipo de header
        private int Headertype()
        {
            int header = 0;
            switch (rede)
            {
                case "02": header = 5; break;
                case "03": header = 3; break;
                case "04": header = 6; break;
                case "07": header = 2; break;
                case "08": header = 2; break;
            }

            var sizeHeader = 0;
            switch (header)
            {
                case (int)ISOMessageHeader.ASCII:
                    ParserAsc prsAsc = new ParserAsc();
                    parser = prsAsc.Instantiate(new DataElements().GetDataElements(rede));
                    sizeHeader = 4;
                    break;
                case (int)ISOMessageHeader.BIGASCIIPARCIAL:
                    ParserBigAscParcial prsBigAscii = new ParserBigAscParcial();
                    parser = prsBigAscii.Instantiate(new DataElements().GetDataElements(rede));
                    sizeHeader = 2;
                    break;
                case (int)ISOMessageHeader.BIGASCII:
                    ParserBigAsc prsBigAsc = new ParserBigAsc();
                    parser = prsBigAsc.Instantiate(new DataElements().GetDataElements(rede));
                    sizeHeader = 2;
                    break;
                case (int)ISOMessageHeader.ASCIIParcial:
                    sizeHeader = 4;
                    ParserPartialAsc prsPartial = new ParserPartialAsc();
                    parser = prsPartial.Instantiate(new DataElements().GetDataElements(rede));
                    break;
                case (int)ISOMessageHeader.BIGASCIITPDU:
                    sizeHeader = 2;
                    ParserBigAscTPDU prsBifAscTpdu = new ParserBigAscTPDU();
                    parser = prsBifAscTpdu.Instantiate(new DataElements().GetDataElements(rede));
                    break;
                case (int)ISOMessageHeader.LITTLEASCIIPARTIAL:
                    ParserPartialLittleAsc prsPartialLittle = new ParserPartialLittleAsc();
                    parser = prsPartialLittle.Instantiate(new DataElements().GetDataElements(rede));
                    sizeHeader = 2;
                    break;
                case (int)ISOMessageHeader.BIGASCIIVISA:
                    ParserVisa prsBigAsciiVisa = new ParserVisa();
                    parser = prsBigAsciiVisa.Instantiate(new DataElements().GetDataElements(rede));
                    sizeHeader = 4;
                    break;
                default:
                    sizeHeader = 0;
                    break;
            }
            return sizeHeader;
        }
        #endregion

        #region header
        public byte[] AddHeaderSize(byte[] array)
        {
            byte[] bytes = new byte[array.Length + 2];

            byte[] b = BitConverter.GetBytes(array.Length);
            Array.Reverse(b);
            bytes[0] = b[2];
            bytes[1] = b[3];

            Buffer.BlockCopy(array, 0, bytes, 2, array.Length);

            return bytes;
        }

        public byte[] AddHeaderSizeElo(byte[] array)
        {
            //int sizeBit55 = string.IsNullOrEmpty(bit55) ? 0 : bit55.Length / 2;
            //int sizeArray = (array.Length - sizeBit55) + 5;

            int sizeArray = array.Length + 5;

            byte[] header = new byte[2];
            byte[] bytes = new byte[sizeArray + 2];

            byte[] b_endian = BitConverter.GetBytes(sizeArray);
            Array.Reverse(b_endian);
            b_endian[0] = b_endian[2];
            b_endian[1] = b_endian[3];
            Buffer.BlockCopy(b_endian, 0, bytes, 0, header.Length);

            //header = Encoding.ASCII.GetBytes(sizeArray.ToString().PadLeft(4, '0'));
            //Buffer.BlockCopy(header, 0, bytes, 0, 4);
            bytes[2] = 0x60;
            bytes[3] = 0x00;
            bytes[4] = 0x06;
            bytes[5] = 0x00;
            bytes[6] = 0x00;
            Buffer.BlockCopy(array, 0, bytes, 7, sizeArray - 5);

            return bytes;
        }
        
        public byte[] AddHeaderSizeVisa(byte[] array)
        {
            List<byte> bytes = new List<byte>();

            byte[] tamanhoMensagem = BitConverter.GetBytes(array.Length + 22);
            byte[] tamanhoTotal = BitConverter.GetBytes(array.Length + 22);
            Array.Reverse(tamanhoMensagem);
            Array.Reverse(tamanhoTotal);

            bytes.Add(tamanhoTotal[2]);
            bytes.Add(tamanhoTotal[3]);
            bytes.Add(tamanhoTotal[0]);
            bytes.Add(tamanhoTotal[1]);

            bytes.Add(22);                                              // header field 1
            bytes.Add(1);                                               // header field 2
            bytes.Add(2);                                               // header field 3
            bytes.Add(tamanhoMensagem[2]);                              // header field 4
            bytes.Add(tamanhoMensagem[3]);                              // header field 4
            bytes.Add(0);                                               // header field 5
            bytes.Add(0);                                               // header field 5
            bytes.Add(0);                                               // header field 5
            bytes.Add(0);                                               // header field 6
            bytes.Add(0);                                               // header field 6
            bytes.Add(0);                                               // header field 6
            bytes.Add(0);                                               // header field 7
            bytes.Add(0);                                               // header field 8
            bytes.Add(0);                                               // header field 8
            bytes.Add(0);                                               // header field 9
            bytes.Add(0);                                               // header field 9
            bytes.Add(0);                                               // header field 9
            bytes.Add(0);                                               // header field 10
            bytes.Add(0);                                               // header field 11
            bytes.Add(0);                                               // header field 11
            bytes.Add(0);                                               // header field 11
            bytes.Add(0);                                               // header field 12

            bytes.AddRange(array);
            return bytes.ToArray();
        }
        #endregion

    }
}