﻿namespace BMGGRebatedor.BMGGIso
{
    public enum ISOMessageType
    {
        ASCII = 1,
        HEXA = 2,
        DECIMAL = 3
    }
}
