﻿using System.Collections.Generic;

namespace BMGGRebatedor.BMGGIso
{
    public class DataElements
    {

        #region get DataElements
        public List<ModelBit> GetDataElements(string rede)
        {
            List<ModelBit> de = new List<ModelBit>();
            switch (rede)
            {
                case "01": case "001": de = BitsRedeRedsys(); break;
                case "02": case "002": de = BitsVisa(); break;
                case "03": case "003": de = BitsMaster(); break;
                case "04": case "004": de = BitsELO(); break;
                case "07": case "007": de = BitsRedeGlobal(); break;
                case "08": case "008": de = BitsRedeFepas(); break;
                case "09": case "009": de = BitsRedeTelenet(); break;
                case "20": case "020": de = BitsRedeSorocred(); break;
                case "27": case "027": de = BitsRedeInfoxNet(); break;
                case "30": case "030": de = BitsRedeComunix(); break;
                case "50": case "050": de = BitsRedeSoftNex(); break;
                case "55": case "055": de = BitsRedeTicket(); break;
                case "65": case "065": de = BitsRedeVR(); break;
                case "70": case "070": de = BitsAlgorix(); break;
                case "80": case "080": de = BitsRedeValleExpress(); break;
                default: break;
            }
            return de;
        }
        #endregion

        #region visa
        private List<ModelBit> BitsVisa()
        {
            List<ModelBit> DE = new List<ModelBit>();

            DE.Add(new ModelBit(2, "PAN", ETipo.LvarDecimalBCDPan, 11, ""));
            DE.Add(new ModelBit(3, "COD_PROCESSAMENTO", ETipo.NumericBCD, 3, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.AmountBCD, 6, ""));
            DE.Add(new ModelBit(5, "VALOR_LIQUIDACAO", ETipo.AmountBCD, 6, ""));
            DE.Add(new ModelBit(6, "VALOR_FATURAMENTO", ETipo.AmountBCD, 6, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.NumericBCD, 5, ""));
            DE.Add(new ModelBit(9, "FATOR_LIQUIDACAO", ETipo.NumericBCD, 4, ""));
            DE.Add(new ModelBit(10, "FATOR_FATURAMENTO", ETipo.NumericBCD, 4, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.NumericBCD, 3, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.NumericBCD, 3, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(15, "DATA_LIQUIDACAO", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(16, "DATA_CONVERSAO", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(17, "DATA_CAPTURA", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(18, "MCC", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(19, "ACQUIRING_COUNTRY_CODE", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(20, "PAN_COUNTRY_CODE", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(25, "CODIGO_CAPTURA_CONDICAO", ETipo.NumericBCD, 1, ""));
            DE.Add(new ModelBit(26, "CODIGO_CAPTURA_PIN", ETipo.NumericBCD, 1, ""));
            DE.Add(new ModelBit(28, "TAXA_TRANSACAO", ETipo.AlphanumericEBCDIC, 9, ""));
            DE.Add(new ModelBit(32, "IDENTIFICACAO_REDE_CAPTURA", ETipo.LvarDecimalBcd, 7, ""));
            DE.Add(new ModelBit(33, "INSTITUICAO_TRANSMISSAO", ETipo.LvarBinaryBCD, 7, ""));
            DE.Add(new ModelBit(34, "DADOS_COMERCIO_ELETRONICO", ETipo.LLvarBinary, 999, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LvarDecimalBynaryPan, 20, ""));
            DE.Add(new ModelBit(37, "NSU_REDE_CAPTURA", ETipo.AlphanumericEBCDIC, 12, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.AlphanumericEBCDIC, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.AlphanumericEBCDIC, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.AlphanumericEBCDIC, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.AlphanumericEBCDIC, 15, ""));
            DE.Add(new ModelBit(43, "DADOS_ESTABELECIMENTO", ETipo.AlphanumericEBCDIC, 40, ""));
            DE.Add(new ModelBit(44, "DADOS_RESPOSTA_ADICIONAIS", ETipo.LvarBinaryEBCDIC, 26, ""));
            DE.Add(new ModelBit(46, "VALOR_TAXAS", ETipo.LvarBinaryEBCDIC, 256, ""));

            DE.Add(new ModelBit(48, "BIT48", ETipo.LvarBinaryEBCDIC, 256, ""));

            DE.Add(new ModelBit(49, "CODIGO_MOEDA", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(50, "CODIGO_MOEDA_LIQUIDACAO", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(51, "CURRENCY_CODE", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.FixedBinary, 8, ""));
            DE.Add(new ModelBit(53, "INFORMACOES_SEGURANCA", ETipo.NumericBCD, 8, ""));
            DE.Add(new ModelBit(54, "VALORES_ADICIONAIS", ETipo.LvarBinaryEBCDIC, 121, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LvarBinary, 256, ""));
            DE.Add(new ModelBit(56, "DADOS_PORTADOR", ETipo.LvarBinaryEBCDIC, 256, ""));
            DE.Add(new ModelBit(59, "DADOS_GEOGRAFICOS", ETipo.LvarBinaryEBCDIC, 15, ""));
            DE.Add(new ModelBit(60, "DADOS_POS", ETipo.LvarBinaryBCD, 7, ""));
            DE.Add(new ModelBit(61, "OUTROS_VALORES", ETipo.LvarBinaryBCD, 13, ""));

            DE.Add(new ModelBit(62, "BIT62", ETipo.LvarBinary, 255, ""));

            DE.Add(new ModelBit(63, "BIT63", ETipo.LvarBinary, 255, ""));

            DE.Add(new ModelBit(66, "CODIGO_LIQUIDACAO", ETipo.NumericBCD, 1, ""));
            DE.Add(new ModelBit(68, "CODIGO_PAIS_RECEPTOR", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(69, "CODIGO_PAIS_LIQUIDACAO", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(70, "GERENCIAMENTO_REDE", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(73, "DATA_ACAO", ETipo.NumericBCD, 3, ""));
            DE.Add(new ModelBit(74, "NUMERO_CREDITO", ETipo.NumericBCD, 5, ""));
            DE.Add(new ModelBit(75, "NUMERO_CREDITO_ESTORNO", ETipo.NumericBCD, 5, ""));
            DE.Add(new ModelBit(76, "NUMERO_DEBITO", ETipo.NumericBCD, 5, ""));
            DE.Add(new ModelBit(77, "NUMERO_DEBITO_ESTORNO", ETipo.NumericBCD, 5, ""));
            DE.Add(new ModelBit(86, "VALOR_CREDITO", ETipo.NumericBCD, 8, ""));
            DE.Add(new ModelBit(87, "VALOR_CREDITO_ESTORNO", ETipo.NumericBCD, 8, ""));
            DE.Add(new ModelBit(88, "VALOR_DEBITO", ETipo.NumericBCD, 8, ""));
            DE.Add(new ModelBit(89, "VALOR_DEBITO_ESTORNO", ETipo.NumericBCD, 8, ""));

            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.NumericBCD, 21, ""));
            DE.Add(new ModelBit(91, "CODIGO_ALTERACAO_ARQUIVO", ETipo.AlphanumericEBCDIC, 1, ""));
            DE.Add(new ModelBit(92, "CODIGO_SEGURANCA_ARQUIVO", ETipo.AlphanumericEBCDIC, 2, ""));
            DE.Add(new ModelBit(95, "QUANTIDADES_SUBSTITUICAO", ETipo.AlphanumericEBCDIC, 42, ""));
            DE.Add(new ModelBit(96, "CODIGO_SEGURANCA_MENSAGEM", ETipo.FixedBinary, 8, ""));
            DE.Add(new ModelBit(97, "VALOR_LIQUIDO_LIQUIDACAO", ETipo.AlphanumericEBCDIC, 17, ""));
            DE.Add(new ModelBit(99, "CODIGO_IDENTIFICACAO_INSTITUICAO_LIQUIDACAO", ETipo.LvarBinaryBCD, 7, ""));
            DE.Add(new ModelBit(100, "INSTITUICAO_RECEPTORA", ETipo.LvarBinaryBCD, 7, ""));
            DE.Add(new ModelBit(101, "NOME_ARQUIVO", ETipo.LvarBinaryBCD, 18, ""));
            DE.Add(new ModelBit(102, "ID_CONTA1", ETipo.LvarBinaryEBCDIC, 29, ""));
            DE.Add(new ModelBit(103, "ID_CONTA2", ETipo.LvarBinaryEBCDIC, 29, ""));
            DE.Add(new ModelBit(104, "DESCRICAO_TRANSACAO", ETipo.LvarBinary, 256, ""));
            DE.Add(new ModelBit(105, "DES_KEY", ETipo.FixedBinary, 16, ""));
            DE.Add(new ModelBit(110, "ENCRYPTION_DATA", ETipo.LLvarBinary, 999, ""));
            DE.Add(new ModelBit(114, "DADOS_DOMESTICOS", ETipo.LLvarBinary, 999, ""));
            DE.Add(new ModelBit(115, "CODIGO_RASTREAMENTO", ETipo.LvarBinaryEBCDIC, 25, ""));
            DE.Add(new ModelBit(116, "DADOS_REFERENCIA_EMNISSOR", ETipo.LLvarBinary, 256, ""));
            DE.Add(new ModelBit(117, "BIT117", ETipo.LvarBinaryEBCDIC, 19, ""));
            DE.Add(new ModelBit(118, "DADOS_PAIS", ETipo.LvarBinaryEBCDIC, 256, ""));
            DE.Add(new ModelBit(119, "DADOS_SERVICO_LIQUIDACAO", ETipo.LvarBinaryEBCDIC, 11, ""));
            DE.Add(new ModelBit(120, "DADOS_TRANSACAO_AUXILIARES", ETipo.LLvarBinary, 256, ""));
            DE.Add(new ModelBit(121, "CODIGO_IDENTIFICACAO_EMISSOR", ETipo.LLvarBinary, 12, ""));
            DE.Add(new ModelBit(123, "DADOS_VERIFICACAO", ETipo.LLvarBinary, 256, ""));
            DE.Add(new ModelBit(125, "INFORMACOES_DE_SUPORTE", ETipo.LvarBinary, 256, ""));

            DE.Add(new ModelBit(126, "BIT126", ETipo.LvarBinary, 256, ""));

            DE.Add(new ModelBit(127, "BIT127", ETipo.LvarBinary, 256, ""));

            DE.Add(new ModelBit(130, "PERFIL_CAPACIDADE_TERMINAL", ETipo.FixedBinary, 3, ""));
            DE.Add(new ModelBit(131, "TVR", ETipo.FixedBinary, 5, ""));
            DE.Add(new ModelBit(132, "UMPREDICTABLE_NUMBER", ETipo.FixedBinary, 4, ""));
            DE.Add(new ModelBit(133, "TERMINAL_SERIAL_NUMBER", ETipo.AlphanumericEBCDIC, 8, ""));
            DE.Add(new ModelBit(134, "VISA_DISCRITIONARY_DATA", ETipo.LLvarBinary, 256, ""));
            DE.Add(new ModelBit(135, "ISSUER_DISCRITIONARY_DATA", ETipo.LvarBinary, 16, ""));
            DE.Add(new ModelBit(136, "CRYPTOGRAM", ETipo.FixedBinary, 8, ""));
            DE.Add(new ModelBit(137, "APLICATION_TRANSACTION_COUNTER", ETipo.FixedBinary, 2, ""));
            DE.Add(new ModelBit(138, "APLICATION_INTERCHANGE_PROFILE", ETipo.FixedBinary, 2, ""));
            DE.Add(new ModelBit(139, "ARPC", ETipo.FixedBinary, 10, ""));
            DE.Add(new ModelBit(140, "ISSUER_AUTHENTICATION_DATA", ETipo.LvarBinary, 256, ""));
            DE.Add(new ModelBit(142, "ISSUER_SCRIPT", ETipo.LvarBinary, 256, ""));
            DE.Add(new ModelBit(143, "ISSUER_SCRIPT_RESULTS", ETipo.LvarBinary, 21, ""));
            DE.Add(new ModelBit(144, "CRIPTOGRAM_TRANSACTION_TYPE", ETipo.NumericBCD, 1, ""));
            DE.Add(new ModelBit(145, "TERMINAL_COUNTRY_CODE", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(146, "TERMINAL_TRANSACTION_DATE", ETipo.NumericBCD, 3, ""));
            DE.Add(new ModelBit(147, "CRIPTOGRAM_AMOUNT", ETipo.NumericBCD, 6, ""));
            DE.Add(new ModelBit(148, "CRIPTOGRAM_CURRENCY_CODE", ETipo.NumericBCD, 2, ""));
            DE.Add(new ModelBit(149, "CRIPTOGRAM_CASBACK_AMOUNT", ETipo.NumericBCD, 6, ""));

            return DE;
        }
        #endregion

        #region master
        private List<ModelBit> BitsMaster()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "COD_PROCESSAMENTO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(5, "VALOR_LIQUIDACAO", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(6, "VALOR_FATURAMENTO", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(9, "FATOR_LIQUIDACAO", ETipo.Numeric, 8, ""));
            DE.Add(new ModelBit(10, "FATOR_FATURAMENTO", ETipo.Numeric, 8, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(15, "DATA_LIQUIDACAO", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(16, "DATA_CONVERSAO", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(18, "MCC", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(20, "PAN_COUNTRY_CODE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(26, "CODIGO_CAPTURA_PIN", ETipo.Numeric, 2, ""));
            DE.Add(new ModelBit(28, "TAXA_TRANSACAO", ETipo.Alphanumeric, 9, ""));
            DE.Add(new ModelBit(32, "IDENTIFICACAO_REDE_CAPTURA", ETipo.LLvar, 6, ""));
            DE.Add(new ModelBit(33, "INSTITUICAO_TRANSMISSAO", ETipo.LLvar, 6, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(37, "NSU_REDE_CAPTURA", ETipo.Alphanumeric, 12, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(43, "DADOS_ESTABELECIMENTO", ETipo.Alphanumeric, 40, ""));
            DE.Add(new ModelBit(44, "DADOS_RESPOSTA_ADICIONAIS", ETipo.LLvar, 25, ""));
            DE.Add(new ModelBit(45, "TRILHA_UM", ETipo.LLvar, 76, ""));
            DE.Add(new ModelBit(46, "INFORMACOES_ADICIONAIS_RESPOSTA", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(47, "DADOS_ADICIONAIS_NACIONAIS", ETipo.LLLvar, 999, ""));

            DE.Add(new ModelBit(48, "BIT48", ETipo.LLLvar, 999, ""));

            DE.Add(new ModelBit(48, "BIT48.11", ETipo.LLvar, 54, "11"));
            DE.Add(new ModelBit(48, "BIT48.12", ETipo.LLvar, 1, "12"));
            DE.Add(new ModelBit(48, "BIT48.13", ETipo.LLvar, 47, "13"));
            DE.Add(new ModelBit(48, "BIT48.14", ETipo.LLvar, 1, "14"));
            DE.Add(new ModelBit(48, "BIT48.15", ETipo.LLvar, 10, "15"));
            DE.Add(new ModelBit(48, "BIT48.16", ETipo.LLvar, 7, "16"));
            DE.Add(new ModelBit(48, "BIT48.17", ETipo.LLvar, 2, "17"));
            DE.Add(new ModelBit(48, "BIT48.18", ETipo.LLvar, 99, "18"));
            DE.Add(new ModelBit(48, "BIT48.20", ETipo.LLvar, 1, "20"));
            DE.Add(new ModelBit(48, "BIT48.21", ETipo.LLvar, 2, "21"));
            DE.Add(new ModelBit(48, "BIT48.23", ETipo.LLvar, 2, "23"));
            DE.Add(new ModelBit(48, "BIT48.25", ETipo.LLvar, 14, "25"));
            DE.Add(new ModelBit(48, "BIT48.26", ETipo.LLvar, 3, "26"));
            DE.Add(new ModelBit(48, "BIT48.27", ETipo.LLvar, 2, "27"));
            DE.Add(new ModelBit(48, "BIT48.30", ETipo.LLvar, 2, "30"));
            DE.Add(new ModelBit(48, "BIT48.32", ETipo.LLvar, 6, "32"));
            DE.Add(new ModelBit(48, "BIT48.33", ETipo.LLvar, 93, "33"));
            DE.Add(new ModelBit(48, "BIT48.34", ETipo.LLvar, 11, "34"));
            DE.Add(new ModelBit(48, "BIT48.35", ETipo.LLvar, 1, "35"));
            DE.Add(new ModelBit(48, "BIT48.36", ETipo.LLvar, 14, "36"));
            DE.Add(new ModelBit(48, "BIT48.37", ETipo.LLvar, 49, "37"));
            DE.Add(new ModelBit(48, "BIT48.38", ETipo.LLvar, 1, "38"));
            DE.Add(new ModelBit(48, "BIT48.39", ETipo.LLvar, 30, "39"));
            DE.Add(new ModelBit(48, "BIT48.40", ETipo.LLvar, 40, "40"));
            DE.Add(new ModelBit(48, "BIT48.41", ETipo.LLvar, 95, "41"));
            DE.Add(new ModelBit(48, "BIT48.42", ETipo.LLvar, 7, "42"));
            DE.Add(new ModelBit(48, "BIT48.43", ETipo.LLvar, 32, "43"));
            DE.Add(new ModelBit(48, "BIT48.44", ETipo.LLvar, 20, "44"));
            DE.Add(new ModelBit(48, "BIT48.45", ETipo.LLvar, 1, "45"));
            DE.Add(new ModelBit(48, "BIT48.46", ETipo.LLvar, 2, "46"));
            DE.Add(new ModelBit(48, "BIT48.47", ETipo.LLvar, 8, "47"));
            DE.Add(new ModelBit(48, "BIT48.48", ETipo.LLvar, 73, "48"));
            DE.Add(new ModelBit(48, "BIT48.49", ETipo.LLvar, 15, "49"));
            DE.Add(new ModelBit(48, "BIT48.51", ETipo.LLvar, 99, "51"));
            DE.Add(new ModelBit(48, "BIT48.52", ETipo.LLvar, 2, "52"));
            DE.Add(new ModelBit(48, "BIT48.53", ETipo.LLvar, 99, "53"));
            DE.Add(new ModelBit(48, "BIT48.55", ETipo.LLvar, 32, "55"));
            DE.Add(new ModelBit(48, "BIT48.56", ETipo.LLvar, 99, "56"));
            DE.Add(new ModelBit(48, "BIT48.57", ETipo.LLvar, 99, "57"));
            DE.Add(new ModelBit(48, "BIT48.58", ETipo.LLvar, 33, "58"));
            DE.Add(new ModelBit(48, "BIT48.61", ETipo.LLvar, 5, "61"));
            DE.Add(new ModelBit(48, "BIT48.63", ETipo.LLvar, 15, "63"));
            DE.Add(new ModelBit(48, "BIT48.64", ETipo.LLvar, 4, "64"));
            DE.Add(new ModelBit(48, "BIT48.65", ETipo.LLvar, 2, "65"));
            DE.Add(new ModelBit(48, "BIT48.66", ETipo.LLvar, 45, "66"));
            DE.Add(new ModelBit(48, "BIT48.67", ETipo.LLvar, 99, "67"));
            DE.Add(new ModelBit(48, "BIT48.71", ETipo.LLvar, 40, "71"));
            DE.Add(new ModelBit(48, "BIT48.72", ETipo.LLvar, 16, "72"));
            DE.Add(new ModelBit(48, "BIT48.74", ETipo.LLvar, 30, "74"));
            DE.Add(new ModelBit(48, "BIT48.75", ETipo.LLvar, 32, "75"));
            DE.Add(new ModelBit(48, "BIT48.76", ETipo.LLvar, 1, "76"));
            DE.Add(new ModelBit(48, "BIT48.77", ETipo.LLvar, 3, "77"));
            DE.Add(new ModelBit(48, "BIT48.78", ETipo.LLvar, 6, "78"));
            DE.Add(new ModelBit(48, "BIT48.79", ETipo.LLvar, 50, "79"));
            DE.Add(new ModelBit(48, "BIT48.80", ETipo.LLvar, 2, "80"));
            DE.Add(new ModelBit(48, "BIT48.82", ETipo.LLvar, 2, "82"));
            DE.Add(new ModelBit(48, "BIT48.83", ETipo.LLvar, 1, "83"));
            DE.Add(new ModelBit(48, "BIT48.84", ETipo.LLvar, 2, "84"));
            DE.Add(new ModelBit(48, "BIT48.85", ETipo.LLvar, 1, "85"));
            DE.Add(new ModelBit(48, "BIT48.86", ETipo.LLvar, 1, "86"));
            DE.Add(new ModelBit(48, "BIT48.87", ETipo.LLvar, 1, "87"));
            DE.Add(new ModelBit(48, "BIT48.88", ETipo.LLvar, 1, "88"));
            DE.Add(new ModelBit(48, "BIT48.89", ETipo.LLvar, 1, "89"));
            DE.Add(new ModelBit(48, "BIT48.90", ETipo.LLvar, 1, "90"));
            DE.Add(new ModelBit(48, "BIT48.90", ETipo.LLvar, 1, "90"));
            DE.Add(new ModelBit(48, "BIT48.91", ETipo.LLvar, 19, "91"));
            DE.Add(new ModelBit(48, "BIT48.92", ETipo.LLvar, 3, "92"));
            DE.Add(new ModelBit(48, "BIT48.93", ETipo.LLvar, 19, "93"));
            DE.Add(new ModelBit(48, "BIT48.94", ETipo.LLvar, 4, "94"));
            DE.Add(new ModelBit(48, "BIT48.95", ETipo.LLvar, 6, "95"));
            DE.Add(new ModelBit(48, "BIT48.96", ETipo.LLvar, 1, "96"));
            DE.Add(new ModelBit(48, "BIT48.97", ETipo.LLvar, 1, "97"));
            DE.Add(new ModelBit(48, "BIT48.98", ETipo.LLvar, 6, "98"));
            DE.Add(new ModelBit(48, "BIT48.99", ETipo.LLvar, 6, "99"));

            DE.Add(new ModelBit(49, "CODIGO_MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(50, "MOEDA_LIQUIDACAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(51, "CURRENCY_CODE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.FixedBinary, 8, ""));
            DE.Add(new ModelBit(53, "INFORMACOES_SEGURANCA", ETipo.Numeric, 16, ""));
            DE.Add(new ModelBit(54, "VALORES_ADICIONAIS", ETipo.LLLvar, 240, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvarBinary, 999, ""));
            DE.Add(new ModelBit(56, "DADOSPORTADOR", ETipo.LLLvar, 37, ""));
            DE.Add(new ModelBit(58, "INSTITUICAO_AGENTE_AUTORIZADOR", ETipo.LLLvar, 9, ""));
            DE.Add(new ModelBit(60, "ADVICE_CODE", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(61, "DADOS_POS", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(62, "DADOS_REDE_INTERMEDIARIA", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "DADOS_REDE", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(64, "MAC", ETipo.FixedBinary, 8, ""));
            DE.Add(new ModelBit(65, "BITMAP_EXTENTED", ETipo.FixedBinary, 8, ""));
            DE.Add(new ModelBit(70, "GERENCIAMENTO_REDE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(94, "INDICADOR_SERVICO", ETipo.Alphanumeric, 7, ""));
            DE.Add(new ModelBit(95, "QUANTIDADES_SUBSTITUICAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(96, "CODIGO_SEGURANCA_MENSAGEM", ETipo.Numeric, 8, ""));
            DE.Add(new ModelBit(100, "INSTITUICAO_RECEPTORA", ETipo.LLvar, 11, ""));
            DE.Add(new ModelBit(101, "NOME_ARQUIVO", ETipo.LLLvar, 17, ""));
            DE.Add(new ModelBit(102, "ID_CONTA1", ETipo.LLvar, 28, ""));
            DE.Add(new ModelBit(103, "ID_CONTA2", ETipo.LLLvar, 28, ""));
            DE.Add(new ModelBit(108, "MONEYSEND_REFERENCE_DATA", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(110, "DADOS_ADICIONAIS2", ETipo.LLLvar, 100, ""));
            DE.Add(new ModelBit(111, "AVALIACAO_CONVERSAO_MOEDA", ETipo.LLLvar, 12, ""));
            DE.Add(new ModelBit(112, "DADOS_ADICIONAIS", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(113, "RESERVADO_USO_NACIONAL1", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(114, "RESERVADO_USO_NACIONAL2", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(115, "RESERVADO_USO_NACIONAL3", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(116, "RESERVADO_USO_NACIONAL4", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(117, "RESERVADO_USO_NACIONAL5", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(118, "RESERVADO_USO_NACIONAL6", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(119, "RESERVADO_USO_NACIONAL7", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(120, "DADOS_REGISTRO", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(121, "STANDIN_CODE", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(122, "DADOS_REGISTRO_ADICIONAIS", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(123, "TEXTO_LIVRE", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(124, "DADOS _DEFINIDOS_CLIENTE", ETipo.LLLvar, 299, ""));
            DE.Add(new ModelBit(125, "NEW_PIN", ETipo.FixedBinary, 8, ""));
            DE.Add(new ModelBit(126, "DADOS_PRIVADOS1", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(127, "DADOS_PRIVADOS2", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Owner, 0, ""));
            return DE;
        }
        #endregion

        #region elo
        private List<ModelBit> BitsELO()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "COD_PROCESSAMENTO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(18, "MCC", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(19, "CODIGO_PAIS_CREDENCIADOR", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(24, "CODIGO_FUNCAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(25, "MOTIVOMENSAGEM", ETipo.Numeric, 2, ""));
            DE.Add(new ModelBit(32, "IDENTIFICACAO_REDE_CAPTURA", ETipo.LLvar, 11, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(37, "NSU_REDE_CAPTURA", ETipo.Alphanumeric, 12, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(43, "DADOS_ESTABELECIMENTO", ETipo.Alphanumeric, 40, ""));
            DE.Add(new ModelBit(45, "TRILHA_UM", ETipo.LLvar, 76, ""));
            DE.Add(new ModelBit(46, "INFORMACOES_ADICIONAIS_RESPOSTA", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(47, "DADOS_ADICIONAIS_NACIONAIS", ETipo.LLLvar, 999, ""));

            DE.Add(new ModelBit(48, "BIT48.CNP", ETipo.LLLvar, 999, "*CNP"));                                           // cnpj ou cpf
            DE.Add(new ModelBit(48, "BIT48.VPS", ETipo.LLLvar, 999, "*VPS"));                                           // usado se venda for parcelada
            DE.Add(new ModelBit(48, "BIT48.VPR", ETipo.LLLvar, 999, "*VPR"));                                           // usado na resposta se venda parcelada
            DE.Add(new ModelBit(48, "BIT48.VPS", ETipo.LLLvar, 999, "*VPP"));                                           // usado na resposta se venda parcelada
            DE.Add(new ModelBit(48, "BIT48.SVA", ETipo.LLLvar, 999, "*SVA"));                                           // resposta de consulta de credito
            DE.Add(new ModelBit(48, "BIT48.SPA", ETipo.LLLvar, 999, "*SPA"));                                           // resposta de consulta de credito valor simulado
            DE.Add(new ModelBit(48, "BIT48.SVB", ETipo.LLLvar, 999, "*SVB"));                                           // resposta de consulta de credito num parcelas
            DE.Add(new ModelBit(48, "BIT48.SPB", ETipo.LLLvar, 999, "*SPB"));                                           // resposta de consulta de credito num parcelas svb
            DE.Add(new ModelBit(48, "BIT48.CDT", ETipo.LLLvar, 999, "*CDT"));                                           // trilha 1
            DE.Add(new ModelBit(48, "BIT48.CCD", ETipo.LLLvar, 999, "*CCD"));                                           // certificado digital se ecomerce
            DE.Add(new ModelBit(48, "BIT48.BND", ETipo.LLLvar, 999, "*BND"));                                           // dados BNDS
            DE.Add(new ModelBit(48, "BIT48.PRD", ETipo.LLLvar, 999, "*PRD"));                                           // produto
            DE.Add(new ModelBit(48, "BIT48.RSP", ETipo.LLLvar, 999, "*RSP"));                                           // resposta de pedidos de reversao
            DE.Add(new ModelBit(48, "BIT48.PRE", ETipo.LLLvar, 999, "*PRE"));                                           // usado quando for pré-autorização

            DE.Add(new ModelBit(49, "CODIGO_MOEDA", ETipo.Numeric, 3, ""));

            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 8, ""));
            DE.Add(new ModelBit(53, "INFORMACOES_SEGURANCA", ETipo.Alphanumeric, 16, ""));
            DE.Add(new ModelBit(54, "VALORES_ADICIONAIS", ETipo.LLLvar, 120, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(56, "DADOSPORTADOR", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(58, "DADOS_GEOGRAFICOS", ETipo.LLLvar, 60, ""));
            DE.Add(new ModelBit(60, "DADOS_ADICIONAIS_TERMINAL", ETipo.LLLvar, 13, ""));

            DE.Add(new ModelBit(62, "BIT62.TID", ETipo.LLLvar, 999, "*TID"));                                           // dados do TID
            DE.Add(new ModelBit(62, "BIT62.DCA", ETipo.LLLvar, 999, "*DCA"));                                           // dados do código de autenticaçào
            DE.Add(new ModelBit(62, "BIT62.RVA", ETipo.LLLvar, 999, "*RVA"));                                           // resultado da validaçào do código de autenticação
            DE.Add(new ModelBit(62, "BIT62.TPJ", ETipo.LLLvar, 999, "*TPJ"));                                           // CNPJ do comprador
            DE.Add(new ModelBit(62, "BIT62.TPF", ETipo.LLLvar, 999, "*TPF"));                                           // CPF do comprador
            DE.Add(new ModelBit(62, "BIT62.ECI", ETipo.LLLvar, 999, "*ECI"));                                           // indicador de comercio eletronico
            DE.Add(new ModelBit(62, "BIT62.CAE", ETipo.LLLvar, 999, "*CAE"));                                           // código de autorização elo comercio eletronico

            DE.Add(new ModelBit(70, "GERENCIAMENTO_REDE", ETipo.Numeric, 3, ""));

            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));

            DE.Add(new ModelBit(100, "INSTITUICAO_RECEPTORA", ETipo.LLvar, 11, ""));
            DE.Add(new ModelBit(105, "DADOS_TRANSACAO_ESPECIFICA_2", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(107, "DADOS_TRANSACAO_ESPECIFICA", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(120, "DADOS_CHAVE", ETipo.LLLvar, 24, ""));
            DE.Add(new ModelBit(122, "DADOS_ADICIONAIS_AUTENTICACAO", ETipo.LLLvar, 100, ""));

            DE.Add(new ModelBit(124, "QUALIFICADOR_TRANSACOES", ETipo.LLLvar, 124, ""));

            DE.Add(new ModelBit(125, "CAMPO_USO_PERSONALIZADO", ETipo.LLLvar, 999, ""));

            DE.Add(new ModelBit(126, "IDENTIFICADOR_CARTAO", ETipo.LLLvar, 5, ""));
            DE.Add(new ModelBit(127, "IDENTIFICADOR_VERSAO", ETipo.LLLvar, 5, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Owner, 0, ""));
            return DE;
        }
        #endregion

        #region global payments
        private List<ModelBit> BitsRedeGlobal()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(48, "CARGA_TABELA", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(48, "CARGA_ATUALIZADA", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(48, "FORMA_PAGAMENTO", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(48, "PAN_CRIPTOGRAFADO", ETipo.LLLvar, 999, "005"));
            DE.Add(new ModelBit(48, "QUANTIDADE_PARCELAS", ETipo.LLLvar, 999, "006"));
            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 16, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(60, "CUPOM_CL", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(61, "VERSAO_GP", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(61, "NUMERO_SERIE_PINPAD", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(61, "MASTER_CARD", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(61, "VERSAO_BC_PP", ETipo.LLLvar, 999, "004"));
            DE.Add(new ModelBit(62, "CUPOM_LJ", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "063", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(120, "APROVADA_TARJA_DIGITADA", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(120, "APROVADA_CHIP", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(126, "TIPO_CRIPTOGRAFIA", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(126, "KSN", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(126, "TIPO_CRIPTOGRAFIA_CARTAO", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(126, "CVV_DIGITADO_CREDITO", ETipo.LLLvar, 999, "005"));
            DE.Add(new ModelBit(126, "CVV_DIGITADO_DEBITO", ETipo.LLLvar, 999, "010"));
            DE.Add(new ModelBit(127, "NSU_HOST", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Numeric, 4, ""));
            return DE;
        }
        #endregion

        #region redsys 01.03
        private List<ModelBit> BitsRedeRedsys()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(48, "CARGA_TABELA", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(48, "CARGA_ATUALIZADA", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(48, "FORMA_PAGAMENTO", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(48, "PAN_CRIPTOGRAFADO", ETipo.LLLvar, 999, "005"));
            DE.Add(new ModelBit(48, "QUANTIDADE_PARCELAS", ETipo.LLLvar, 999, "006"));
            DE.Add(new ModelBit(48, "DT_ULTIMA_TROCA_CHAVE", ETipo.LLLvar, 999, "007"));
            DE.Add(new ModelBit(48, "FLAG_TROCA_CHAVE", ETipo.LLLvar, 999, "008"));
            DE.Add(new ModelBit(48, "SOFT_DESCRIPTOR", ETipo.LLLvar, 999, "009"));
            DE.Add(new ModelBit(48, "SOFT_DESCRIPTOR_TXT", ETipo.LLLvar, 999, "010"));
            DE.Add(new ModelBit(48, "ESTATISTICAS_PINPAD", ETipo.LLLvar, 999, "011"));
            DE.Add(new ModelBit(48, "NOME_PORTADOR", ETipo.LLLvar, 999, "012"));
            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 16, ""));
            DE.Add(new ModelBit(54, "VALOR_ORIGINAL", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(60, "CUPOM_CL", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(61, "VERSAO_GP", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(61, "NUMERO_SERIE_PINPAD", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(61, "MASTER_CARD", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(61, "VERSAO_BC_PP", ETipo.LLLvar, 999, "004"));
            DE.Add(new ModelBit(61, "FABRICANTE_PP", ETipo.LLLvar, 999, "005"));
            DE.Add(new ModelBit(61, "MODELO_PP", ETipo.LLLvar, 999, "006"));
            DE.Add(new ModelBit(61, "VERSAO_SW_BASICO", ETipo.LLLvar, 999, "007"));
            DE.Add(new ModelBit(62, "TABELAS_BIT62", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "TABELAS_BIT63", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(90, "DADOS_ORIGINAIS", ETipo.Alphanumeric, 42, ""));
            DE.Add(new ModelBit(120, "DADOS_TRANSACAO_TARJA", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(120, "DADOS_TRANSACAO_EMV", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(120, "STATUS_TRANSACAO_ORIGINAL", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(120, "AUTORIZACAO_TRANSACAO_ORIGINAL", ETipo.LLLvar, 999, "038"));
            DE.Add(new ModelBit(120, "APROVADA_CHIP_TRANSACAO_ORIGINAL", ETipo.LLLvar, 999, "055"));
            DE.Add(new ModelBit(126, "TIPO_CRIPTOGRAFIA", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(126, "KSN_PIN", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(126, "TIPO_CRIPTOGRAFIA_CARTAO", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(126, "KSN_PAN", ETipo.LLLvar, 999, "004"));
            DE.Add(new ModelBit(126, "CVV_DIGITADO_CREDITO", ETipo.LLLvar, 999, "005"));
            DE.Add(new ModelBit(126, "CAVV", ETipo.LLLvar, 999, "006"));
            DE.Add(new ModelBit(126, "CAVV_UCAF", ETipo.LLLvar, 999, "007"));
            DE.Add(new ModelBit(126, "ECI", ETipo.LLLvar, 999, "008"));
            DE.Add(new ModelBit(126, "XID", ETipo.LLLvar, 999, "009"));
            DE.Add(new ModelBit(126, "CVV_DIGITADO_DEBITO", ETipo.LLLvar, 999, "010"));
            DE.Add(new ModelBit(126, "RECORRENTE", ETipo.LLLvar, 999, "011"));
            DE.Add(new ModelBit(127, "NSU_HOST", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Owner, 0, ""));
            return DE;
        }
        #endregion

        #region fepas
        private List<ModelBit> BitsRedeFepas()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(32, "REDE_AUTORIZADORA", ETipo.LLvar, 4, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(37, "NSU_HOST", ETipo.Numeric, 12, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(48, "BIT48.200", ETipo.LLLvar, 999, "200"));
            DE.Add(new ModelBit(48, "BIT48.201", ETipo.LLLvar, 999, "201"));
            DE.Add(new ModelBit(48, "BIT48.202", ETipo.LLLvar, 999, "202"));
            DE.Add(new ModelBit(48, "BIT48.203", ETipo.LLLvar, 999, "203"));
            DE.Add(new ModelBit(48, "BIT48.204", ETipo.LLLvar, 999, "204"));
            DE.Add(new ModelBit(48, "BIT48.205", ETipo.LLLvar, 999, "205"));
            DE.Add(new ModelBit(48, "BIT48.206", ETipo.LLLvar, 999, "206"));
            DE.Add(new ModelBit(48, "BIT48.208", ETipo.LLLvar, 999, "208"));
            DE.Add(new ModelBit(48, "BIT48.209", ETipo.LLLvar, 999, "209"));
            DE.Add(new ModelBit(48, "BIT48.220", ETipo.LLLvar, 999, "220"));
            DE.Add(new ModelBit(48, "BIT48.231", ETipo.LLLvar, 999, "231"));
            DE.Add(new ModelBit(48, "BIT48.232", ETipo.LLLvar, 999, "232"));
            DE.Add(new ModelBit(48, "BIT48.233", ETipo.LLLvar, 999, "233"));
            DE.Add(new ModelBit(48, "BIT48.234", ETipo.LLLvar, 999, "234"));
            DE.Add(new ModelBit(48, "BIT48.236", ETipo.LLLvar, 999, "236"));
            DE.Add(new ModelBit(48, "BIT48.237", ETipo.LLLvar, 999, "237"));
            DE.Add(new ModelBit(48, "BIT48.238", ETipo.LLLvar, 999, "238"));
            DE.Add(new ModelBit(48, "BIT48.240", ETipo.LLLvar, 999, "240"));
            DE.Add(new ModelBit(48, "BIT48.241", ETipo.LLLvar, 999, "241"));
            DE.Add(new ModelBit(48, "BIT48.245", ETipo.LLLvar, 999, "245"));
            DE.Add(new ModelBit(48, "BIT48.246", ETipo.LLLvar, 999, "246"));
            DE.Add(new ModelBit(48, "BIT48.247", ETipo.LLLvar, 999, "247"));
            DE.Add(new ModelBit(48, "BIT48.248", ETipo.LLLvar, 999, "248"));
            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 32, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(60, "BIT60", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(60, "BIT60.001", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(60, "BIT60.002", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(60, "BIT60.003", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(60, "BIT60.100", ETipo.LLLvar, 999, "100"));
            DE.Add(new ModelBit(60, "BIT60.101", ETipo.LLLvar, 999, "101"));
            DE.Add(new ModelBit(60, "BIT60.102", ETipo.LLLvar, 999, "102"));
            DE.Add(new ModelBit(61, "BIT61", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(62, "BIT62", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "BIT63", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(70, "BIT70", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(120, "BIT120", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(125, "BIT125", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(127, "NSU_HOST", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Numeric, 4, ""));
            return DE;
        }
        #endregion

        #region algorix
        private List<ModelBit> BitsAlgorix()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.Numeric, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(32, "032", ETipo.LLvar, 15, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(44, "044", ETipo.LLvar, 99, ""));
            DE.Add(new ModelBit(47, "047", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(48, "CARGA_TABELA", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 16, ""));
            DE.Add(new ModelBit(60, "060", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(61, "TIPO_TERMINAL", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(62, "062", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "063", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(67, "067", ETipo.Numeric, 2, ""));
            DE.Add(new ModelBit(70, "070", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(127, "NSU_HOST", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Owner, 0, ""));

            return DE;
        }
        #endregion

        #region comunix
        private List<ModelBit> BitsRedeComunix()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.Numeric, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(32, "032", ETipo.LLvar, 99, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(48, "CARGA_TABELA", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 16, ""));
            DE.Add(new ModelBit(62, "CUPOM_LJ", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(67, "067", ETipo.Numeric, 2, ""));
            DE.Add(new ModelBit(70, "070", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(127, "NSU_HOST", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Owner, 0, ""));

            return DE;
        }
        #endregion

        #region telenet
        private List<ModelBit> BitsRedeTelenet()
        {
            List<ModelBit> DE = new List<ModelBit>();

            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(5, "SALDO", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(48, "VERSAO_SRV", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(48, "PAN_CRIPTOGRAFADO", ETipo.LLLvar, 999, "005"));
            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 16, ""));
            DE.Add(new ModelBit(61, "061", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(62, "CUPOM_LJ", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "063", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(64, "064", ETipo.Alphanumeric, 16, ""));
            DE.Add(new ModelBit(67, "067", ETipo.Numeric, 2, ""));
            DE.Add(new ModelBit(70, "070", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(104, "TAM_SENHA", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(125, "125", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(127, "NSU_HOST", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Owner, 0, ""));

            return DE;
        }
        #endregion

        #region valle express
        private List<ModelBit> BitsRedeValleExpress()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(32, "REDE_AUTORIZADORA", ETipo.LLvar, 4, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(37, "NSU_HOST", ETipo.Numeric, 12, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(47, "BIT47.023", ETipo.LLLvar, 999, "023"));
            DE.Add(new ModelBit(47, "BIT47.200", ETipo.LLLvar, 999, "200"));
            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 32, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(60, "BIT60", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(60, "BIT60.001", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(60, "BIT60.002", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(60, "BIT60.003", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(60, "BIT60.100", ETipo.LLLvar, 999, "100"));
            DE.Add(new ModelBit(60, "BIT60.101", ETipo.LLLvar, 999, "101"));
            DE.Add(new ModelBit(60, "BIT60.102", ETipo.LLLvar, 999, "102"));
            DE.Add(new ModelBit(61, "BIT61", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(62, "BIT62", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "BIT63", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(120, "BIT120", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(125, "BIT125", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(127, "NSU_HOST", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Numeric, 4, ""));
            return DE;
        }
        #endregion

        #region sorocred
        private List<ModelBit> BitsRedeSorocred()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(18, "MCC", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(33, "IDENTIFICACAOBANDEIRA", ETipo.LLvar, 11, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(37, "NSU_HOST", ETipo.Alphanumeric, 12, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(43, "NOME_EC", ETipo.Alphanumeric, 40, ""));
            DE.Add(new ModelBit(45, "TRILHA_1", ETipo.LLvar, 76, ""));

            DE.Add(new ModelBit(48, "BIT48.CVV", ETipo.LLLvar, 999, "CVV"));                        // codigo cvv
            DE.Add(new ModelBit(48, "BIT48.CPL", ETipo.LLLvar, 999, "CPL"));                        // compra parcelada loja
            DE.Add(new ModelBit(48, "BIT48.CPE", ETipo.LLLvar, 999, "CPE"));                        // compra parcelada emissor
            DE.Add(new ModelBit(48, "BIT48.SLD", ETipo.LLLvar, 999, "SLD"));                        // saldo disponivel
            DE.Add(new ModelBit(48, "BIT48.FIN", ETipo.LLLvar, 999, "FIN"));                        // informações sobre financiamento
            DE.Add(new ModelBit(48, "BIT48.NOM", ETipo.LLLvar, 999, "NOM"));                        // nome do cliente igual impresso cartao
            DE.Add(new ModelBit(48, "BIT48.DNA", ETipo.LLLvar, 999, "DNA"));                        // data nascimento do portador
            DE.Add(new ModelBit(48, "BIT48.CEP", ETipo.LLLvar, 999, "CEP"));                        // cep de onde a fatura e entregue
            DE.Add(new ModelBit(48, "BIT48.CPF", ETipo.LLLvar, 999, "CPF"));                        // cpf do cliente
            DE.Add(new ModelBit(48, "BIT48.TOK", ETipo.LLLvar, 999, "TOK"));                        // token (vdp)
            DE.Add(new ModelBit(48, "BIT48.CEL", ETipo.LLLvar, 999, "CEL"));                        // celular 
            DE.Add(new ModelBit(48, "BIT48.DES", ETipo.LLLvar, 999, "DES"));                        // tipo de criptografia
            DE.Add(new ModelBit(48, "BIT48.BAR", ETipo.LLLvar, 999, "BAR"));                        // codigo barras p/ pagto de fatura
            DE.Add(new ModelBit(48, "BIT48.DAE", ETipo.LLLvar, 999, "DAE"));                        // dados adicionais do sub-estabelecimento
            DE.Add(new ModelBit(48, "BIT48.TAB", ETipo.LLLvar, 999, "TAB"));                        // versao da tabela de working key
            DE.Add(new ModelBit(48, "BIT48.IWT", ETipo.LLLvar, 999, "IWT"));                        // indice da working key 3des
            DE.Add(new ModelBit(48, "BIT48.IWU", ETipo.LLLvar, 999, "IWU"));                        // indice da working key utilizada na autorização
            DE.Add(new ModelBit(48, "BIT48.CDP", ETipo.LLLvar, 999, "CDP"));                        // código do produto
            DE.Add(new ModelBit(48, "BIT48.WKK", ETipo.LLLvar, 999, "WKK"));                        // working key a ser utilizada na criptografia DES

            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 16, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(61, "061", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(62, "062", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "063", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(70, "GERENCIAMENTOREDE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Numeric, 4, ""));

            return DE;
        }
        #endregion

        #region infoxnet
        private List<ModelBit> BitsRedeInfoxNet()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 16, ""));
            DE.Add(new ModelBit(53, "BIT53", ETipo.LLvar, 16, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(62, "BIT62", ETipo.LLLLvar, 999, ""));
            DE.Add(new ModelBit(63, "BIT63", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(67, "BIT67", ETipo.Numeric, 2, ""));
            DE.Add(new ModelBit(70, "GERENCIAMENTOREDE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(119, "TABELA_TAGS", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(120, "TABELA_PKI", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(123, "SERIAL_TERMINAL", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(125, "NSU_HOST_CANCELAMENTO", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(127, "NSU_HOST", ETipo.LLLvar, 9999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Numeric, 4, ""));

            return DE;
        }
        #endregion

        #region ticket
        private List<ModelBit> BitsRedeTicket()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(18, "MCC", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(19, "COUNTRY_CODE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(32, "IDENTIFICACAO_REDE_CAPTURA", ETipo.LLvar, 11, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(37, "NSU_HOST", ETipo.Alphanumeric, 12, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));

            DE.Add(new ModelBit(48, "BIT48", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(48, "BIT48.99", ETipo.LLLvar, 999, "99"));
            DE.Add(new ModelBit(48, "CODIGO_SEGURANCA", ETipo.LLLLvar, 3, "0004"));
            DE.Add(new ModelBit(48, "TECNOLOGIA_TERMINAL", ETipo.LLLLvar, 2, "0032"));
            DE.Add(new ModelBit(48, "STATUS_TRANSACAO_OFFLINE", ETipo.LLLLvar, 2, "0033"));
            DE.Add(new ModelBit(48, "ORIGEM_DESFAZIMENTO", ETipo.LLLLvar, 1, "0037"));
            DE.Add(new ModelBit(48, "VERSAO_ISO", ETipo.LLLLvar, 3, "0040"));
            DE.Add(new ModelBit(48, "NSU_TERMINAL_OFFLINE", ETipo.LLLLvar, 6, "0048"));
            DE.Add(new ModelBit(48, "DATA_TERMINAL_COMPRA_OFF", ETipo.LLLLvar, 6, "0049"));
            DE.Add(new ModelBit(48, "HORA_TERMINAL_COMPRA_OFF", ETipo.LLLLvar, 6, "0050"));
            DE.Add(new ModelBit(48, "TRATAMENTO_PINBLOCK", ETipo.LLLLvar, 3, "0051"));
            DE.Add(new ModelBit(48, "CARDHOLDER_NAME", ETipo.LLLLvar, 90, "0056"));
            DE.Add(new ModelBit(48, "CASAS_DECIMAIS_MOEDA", ETipo.LLLLvar, 1, "0078"));
            DE.Add(new ModelBit(48, "TIPO_CRIPTOGRAFIA_PIN", ETipo.LLLLvar, 3, "0079"));
            DE.Add(new ModelBit(48, "ISSUER_SCRIPT_RESULTS", ETipo.LLLLvar, 66, "0156"));
            DE.Add(new ModelBit(48, "INFORMACOES_FINANCIAMENTO", ETipo.LLLLvar, 10, "0221"));
            DE.Add(new ModelBit(48, "COMPROVANTE_ESTABELECIMENTO", ETipo.LLLLvar, 999, "0239"));
            DE.Add(new ModelBit(48, "COMPROVANTE_CLIENTE", ETipo.LLLLvar, 999, "0240"));

            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 16, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 512, ""));

            DE.Add(new ModelBit(62, "BIT62.99", ETipo.LLLvar, 999, "99"));
            DE.Add(new ModelBit(62, "BIT62.0015", ETipo.Numeric, 12, ""));

            DE.Add(new ModelBit(70, "GERENCIAMENTOREDE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Numeric, 4, ""));

            return DE;
        }
        #endregion

        #region VR
        private List<ModelBit> BitsRedeVR()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(32, "REDE_AUTORIZADORA", ETipo.LLvar, 4, ""));
            DE.Add(new ModelBit(33, "CODIGO_FACILITADOR", ETipo.LLvar, 4, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(37, "SEQUENCE", ETipo.Numeric, 12, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(40, "VERSAO_INTERFACE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));

            DE.Add(new ModelBit(48, "BIT48.200", ETipo.LLLvar, 999, "200"));
            DE.Add(new ModelBit(48, "BIT48.201", ETipo.LLLvar, 999, "201"));
            DE.Add(new ModelBit(48, "BIT48.202", ETipo.LLLvar, 999, "202"));
            DE.Add(new ModelBit(48, "BIT48.203", ETipo.LLLvar, 999, "203"));
            DE.Add(new ModelBit(48, "BIT48.204", ETipo.LLLvar, 999, "204"));
            DE.Add(new ModelBit(48, "BIT48.205", ETipo.LLLvar, 999, "205"));
            DE.Add(new ModelBit(48, "BIT48.206", ETipo.LLLvar, 999, "206"));
            DE.Add(new ModelBit(48, "BIT48.208", ETipo.LLLvar, 999, "208"));
            DE.Add(new ModelBit(48, "BIT48.209", ETipo.LLLvar, 999, "209"));
            DE.Add(new ModelBit(48, "BIT48.220", ETipo.LLLvar, 999, "220"));
            DE.Add(new ModelBit(48, "BIT48.231", ETipo.LLLvar, 999, "231"));
            DE.Add(new ModelBit(48, "BIT48.232", ETipo.LLLvar, 999, "232"));
            DE.Add(new ModelBit(48, "BIT48.233", ETipo.LLLvar, 999, "233"));
            DE.Add(new ModelBit(48, "BIT48.234", ETipo.LLLvar, 999, "234"));
            DE.Add(new ModelBit(48, "BIT48.236", ETipo.LLLvar, 999, "236"));
            DE.Add(new ModelBit(48, "BIT48.237", ETipo.LLLvar, 999, "237"));
            DE.Add(new ModelBit(48, "BIT48.238", ETipo.LLLvar, 999, "238"));
            DE.Add(new ModelBit(48, "BIT48.240", ETipo.LLLvar, 999, "240"));
            DE.Add(new ModelBit(48, "BIT48.241", ETipo.LLLvar, 999, "241"));
            DE.Add(new ModelBit(48, "BIT48.245", ETipo.LLLvar, 999, "245"));
            DE.Add(new ModelBit(48, "BIT48.246", ETipo.LLLvar, 999, "246"));
            DE.Add(new ModelBit(48, "BIT48.247", ETipo.LLLvar, 999, "247"));
            DE.Add(new ModelBit(48, "BIT48.248", ETipo.LLLvar, 999, "248"));
            DE.Add(new ModelBit(48, "BIT48.254", ETipo.LLLvar, 999, "254"));
            DE.Add(new ModelBit(48, "BIT48.261", ETipo.LLLvar, 999, "261")); 
            DE.Add(new ModelBit(48, "BIT48.262", ETipo.LLLvar, 999, "262"));
            DE.Add(new ModelBit(48, "BIT48.267", ETipo.LLLvar, 999, "267"));

            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 32, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(60, "BIT60", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(60, "BIT60.001", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(60, "BIT60.002", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(60, "BIT60.003", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(60, "BIT60.100", ETipo.LLLvar, 999, "100"));
            DE.Add(new ModelBit(60, "BIT60.101", ETipo.LLLvar, 999, "101"));
            DE.Add(new ModelBit(60, "BIT60.102", ETipo.LLLvar, 999, "102"));
            DE.Add(new ModelBit(61, "BIT61", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(62, "BIT62", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "BIT63", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(70, "BIT70", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(120, "BIT120", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(125, "BIT125", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(127, "NSU_HOST", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Numeric, 4, ""));
            return DE;
        }
        #endregion

        #region cabal
        private List<ModelBit> BitsRedeCabal()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(5, "VALOR_BIT5", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(6, "VALOR_BIT6", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(9, "TX_VALOR_REFERENCIA", ETipo.Numeric, 8, ""));
            DE.Add(new ModelBit(10, "TX_VALOR_PARTICIPANTE", ETipo.Numeric, 8, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(18, "MCC", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(23, "VIA_CARTAO", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(26, "CAPACIDADE_PIN", ETipo.Numeric, 2, ""));
            DE.Add(new ModelBit(28, "TARIFA_TRANSACAO", ETipo.Alphanumeric, 9, ""));
            DE.Add(new ModelBit(29, "VALOR_IOF", ETipo.Alphanumeric, 9, ""));
            DE.Add(new ModelBit(32, "REDE_AUTORIZADORA", ETipo.LLvar, 11, ""));
            DE.Add(new ModelBit(33, "CODIGO_FACILITADOR", ETipo.LLvar, 11, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(37, "SEQUENCE", ETipo.Numeric, 12, ""));
            DE.Add(new ModelBit(38, "CODIGO_AUTORIZACAO", ETipo.Alphanumeric, 6, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(40, "VERSAO_INTERFACE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(43, "NOME_COMERCIO", ETipo.Alphanumeric, 40, ""));

            DE.Add(new ModelBit(48, "BIT48.01", ETipo.LLLvar, 999, "01"));
            DE.Add(new ModelBit(48, "BIT48.02", ETipo.LLLvar, 999, "02"));
            DE.Add(new ModelBit(48, "BIT48.03", ETipo.LLLvar, 999, "03"));
            DE.Add(new ModelBit(48, "BIT48.04", ETipo.LLLvar, 999, "04"));
            DE.Add(new ModelBit(48, "BIT48.05", ETipo.LLLvar, 999, "05"));
            DE.Add(new ModelBit(48, "BIT48.11", ETipo.LLLvar, 999, "11"));
            DE.Add(new ModelBit(48, "BIT48.12", ETipo.LLLvar, 999, "12"));
            DE.Add(new ModelBit(48, "BIT48.24", ETipo.LLLvar, 999, "24"));
            DE.Add(new ModelBit(48, "BIT48.40", ETipo.LLLvar, 999, "40"));
            DE.Add(new ModelBit(48, "BIT48.41", ETipo.LLLvar, 999, "41"));
            DE.Add(new ModelBit(48, "BIT48.43", ETipo.LLLvar, 999, "43"));
            DE.Add(new ModelBit(48, "BIT48.44", ETipo.LLLvar, 999, "44"));
            DE.Add(new ModelBit(48, "BIT48.45", ETipo.LLLvar, 999, "45"));

            DE.Add(new ModelBit(49, "MOEDA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(50, "MOEDA_REFERENCIA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(51, "MOEDA_PARTICIPANTE_EMISSOR", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.Numeric, 32, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(60, "BIT60", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(61, "BIT61", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(62, "BIT62", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "BIT63", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(70, "BIT70", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(95, "VALOR_SUBSTITUICAO", ETipo.Numeric, 42, ""));
            DE.Add(new ModelBit(112, "BIT112", ETipo.LLLvar, 999, ""));

            DE.Add(new ModelBit(112, "BIT112.001", ETipo.LLLvar, 999, "001"));

            DE.Add(new ModelBit(124, "BIT124", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(126, "FRAUD_SCORE", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(129, "MTI", ETipo.Numeric, 4, ""));
            return DE;
        }
        #endregion
        
        #region softnex
        private List<ModelBit> BitsRedeSoftNex()
        {
            List<ModelBit> DE = new List<ModelBit>();
            DE.Add(new ModelBit(2, "PAN", ETipo.LLvar, 19, ""));
            DE.Add(new ModelBit(3, "TIPO_TRANSACAO", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(4, "VALOR", ETipo.Amount, 12, ""));
            DE.Add(new ModelBit(7, "DATA_HORA", ETipo.Numeric, 10, ""));
            DE.Add(new ModelBit(11, "NSU_PDV", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(12, "HORA_LOCAL", ETipo.Numeric, 6, ""));
            DE.Add(new ModelBit(13, "DATA_LOCAL", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(14, "VALIDADE", ETipo.Numeric, 4, ""));
            DE.Add(new ModelBit(22, "FORMA_CAPTURA", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(32, "INSTITUICAO_AUTORIZADORA", ETipo.LLvar, 10, ""));
            DE.Add(new ModelBit(35, "TRILHA_DOIS", ETipo.LLvar, 37, ""));
            DE.Add(new ModelBit(39, "CODIGO_RESPOSTA", ETipo.Alphanumeric, 2, ""));
            DE.Add(new ModelBit(41, "IDENTIFICACAO_TERMINAL", ETipo.Alphanumeric, 8, ""));
            DE.Add(new ModelBit(42, "NUMERO_LOGICO", ETipo.Alphanumeric, 15, ""));
            DE.Add(new ModelBit(43, "INFO_ESTABELECIMENTO", ETipo.Alphanumeric, 40, ""));
            
            DE.Add(new ModelBit(48, "BIT48.001", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(48, "BIT48.002", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(48, "BIT48.003", ETipo.LLLvar, 999, "003"));
            DE.Add(new ModelBit(48, "BIT48.004", ETipo.LLLvar, 999, "004"));
            DE.Add(new ModelBit(48, "BIT48.005", ETipo.LLLvar, 999, "005"));
            DE.Add(new ModelBit(48, "BIT48.006", ETipo.LLLvar, 999, "006"));
            DE.Add(new ModelBit(48, "BIT48.007", ETipo.LLLvar, 999, "007"));
            DE.Add(new ModelBit(48, "BIT48.064", ETipo.LLLvar, 999, "064"));
            DE.Add(new ModelBit(48, "BIT48.065", ETipo.LLLvar, 999, "065"));
            DE.Add(new ModelBit(48, "BIT48.066", ETipo.LLLvar, 999, "066"));
            DE.Add(new ModelBit(48, "BIT48.067", ETipo.LLLvar, 999, "067"));
            DE.Add(new ModelBit(48, "BIT48.068", ETipo.LLLvar, 999, "068"));
            DE.Add(new ModelBit(48, "BIT48.069", ETipo.LLLvar, 999, "069"));
            DE.Add(new ModelBit(48, "BIT48.070", ETipo.LLLvar, 999, "070"));
            DE.Add(new ModelBit(48, "BIT48.071", ETipo.LLLvar, 999, "071"));
            DE.Add(new ModelBit(48, "BIT48.072", ETipo.LLLvar, 999, "072"));
            DE.Add(new ModelBit(48, "BIT48.073", ETipo.LLLvar, 999, "073"));
            DE.Add(new ModelBit(48, "BIT48.080", ETipo.LLLvar, 999, "080"));
            DE.Add(new ModelBit(48, "BIT48.081", ETipo.LLLvar, 999, "081"));

            DE.Add(new ModelBit(52, "PIN_CRIPTOGRAFADO", ETipo.FixedBinary, 16, ""));
            DE.Add(new ModelBit(55, "TAGS_CHIP", ETipo.LLLvarBinary, 999, ""));
            
            DE.Add(new ModelBit(59, "BIT59.001", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(59, "BIT59.001", ETipo.LLLvar, 999, "002"));

            DE.Add(new ModelBit(61, "BIT61.001", ETipo.LLLvar, 999, "001"));
            DE.Add(new ModelBit(61, "BIT61.002", ETipo.LLLvar, 999, "002"));
            DE.Add(new ModelBit(61, "BIT61.004", ETipo.LLLvar, 999, "004"));
            DE.Add(new ModelBit(61, "BIT61.005", ETipo.LLLvar, 999, "005"));
            DE.Add(new ModelBit(61, "BIT61.006", ETipo.LLLvar, 999, "006"));
            DE.Add(new ModelBit(61, "BIT61.007", ETipo.LLLvar, 999, "007"));
            
            DE.Add(new ModelBit(62, "CUPOM_LJ", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(63, "063", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(67, "BIT67", ETipo.Numeric, 2, ""));
            DE.Add(new ModelBit(70, "GERENCIAMENTO_REDE", ETipo.Numeric, 3, ""));
            DE.Add(new ModelBit(90, "DADOS_TRANSACAO", ETipo.Alphanumeric, 42, ""));
            DE.Add(new ModelBit(121, "BIT121.001", ETipo.LLLvar, 12, "001"));
            DE.Add(new ModelBit(121, "BIT121.002", ETipo.LLLvar, 12, "002"));
            DE.Add(new ModelBit(121, "BIT121.003", ETipo.LLLvar, 12, "003"));
            DE.Add(new ModelBit(121, "BIT121.004", ETipo.LLLvar, 12, "004"));
            DE.Add(new ModelBit(121, "BIT121.005", ETipo.LLLvar, 12, "005"));
            DE.Add(new ModelBit(121, "BIT121.006", ETipo.LLLvar, 12, "006"));
            DE.Add(new ModelBit(122, "CVV", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(123, "RECEITA_MEDICA", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(125, "NSU_HOST_CANCELAMENTO", ETipo.LLLvar, 999, ""));
            DE.Add(new ModelBit(127, "NSU_HOST_APROVADA", ETipo.LLLvar, 999, ""));
            return DE;
        }
        #endregion

    }
}
