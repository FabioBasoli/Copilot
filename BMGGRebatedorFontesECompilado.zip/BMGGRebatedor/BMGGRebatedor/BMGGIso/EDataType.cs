namespace BMGGRebatedor.BMGGIso
{
    public enum EDataType
    {
        HEXA = 1,
        EBCDIC = 2,
        BCD = 3,
        DECIMAL = 4

    }
}