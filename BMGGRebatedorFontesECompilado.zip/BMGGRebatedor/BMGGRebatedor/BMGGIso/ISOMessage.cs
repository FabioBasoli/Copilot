﻿using System;
using System.Text;

namespace BMGGRebatedor.BMGGIso
{
    public class ISOMessage
    {

        public ISOMessageHeader PacketHeader { get; private set; }
        public ISOMessageType PacketType { get; set; }

        public byte[] PacketDataByte { get; set; }
        public byte[] PacketRecByte { get; set; }

        public byte[] PacketSize
        {
            get
            {
                int size = 0;
                byte[] bytes = null;
                switch (PacketHeader)
                {
                    case ISOMessageHeader.ASCII:
                        bytes = new byte[4];
                        size = PacketDataByte.Length + 4;
                        bytes = Encoding.ASCII.GetBytes(size.ToString().PadLeft(4, '0'));
                        break;
                    case ISOMessageHeader.ASCIIParcial:
                        bytes = new byte[4];
                        size = PacketDataByte.Length;
                        bytes = Encoding.ASCII.GetBytes(size.ToString().PadLeft(4, '0'));
                        break;
                    case ISOMessageHeader.BIGASCII:
                        byte[] b = BitConverter.GetBytes(PacketDataByte.Length);
                        Array.Reverse(b);
                        bytes = new byte[2];
                        bytes[0] = b[2];
                        bytes[1] = b[3];
                        break;
                }
                return bytes;
            }
        }

        public ISOMessage(byte[] message, ISOMessageHeader messageHeader, ISOMessageType messageType)
        {
            this.PacketType = messageType;
            this.PacketHeader = messageHeader;
            this.PacketDataByte = new byte[message.Length];

            Array.Copy(message, 0, PacketDataByte, 0, message.Length);
        }

        public ISOMessage(ISOMessageHeader messagetype)
        {
            PacketHeader = messagetype;
        }

    }
}
