﻿namespace BMGGRebatedor.BMGGIso
{
    public class ModelBit
    {
        public int idBit { get; set; }
        public string nomeBit { get; set; }
        public ETipo tipobit { get; set; }
        public int tamanhoBit { get; set; }
        public string idTlv { get; set; }

        public ModelBit(int id, string nome, ETipo tipo, int tam, string tlv)
        {
            idBit = id;
            nomeBit = nome;
            tipobit = tipo;
            tamanhoBit = tam;
            idTlv = tlv;
        }
    }
}
