﻿namespace BMGGRebatedor.BMGGIso
{
    public class FormatTLV
    {
        public int id { get; set; }
        public int tamanho { get; set; }
        public string valor { get; set; }

        public FormatTLV(int _id, int _tam, string _val)
        {
            id = _id;
            tamanho = _tam;
            valor = _val;
        }
    }
}
