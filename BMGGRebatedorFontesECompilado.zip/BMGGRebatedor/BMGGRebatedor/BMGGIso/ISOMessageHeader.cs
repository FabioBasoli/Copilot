﻿namespace BMGGRebatedor.BMGGIso
{
    public enum ISOMessageHeader
    {
        ASCII = 1,              // soma o lenght com 4 digitos ao tamanho do pacote
        BIGASCIIPARCIAL = 2,    // tamanho da mensagem somente com 2 bytes
        BIGASCII = 3,           // tamanho da mensagem somente com 2 bytes (header no tamanho)
        ASCIIParcial = 4,       // coloca o tamanho somente do pacote no header
        BIGASCIIVISA = 5,       // coloca o tamanho somente do pacote no header com 2 bytes bigendian
        BIGASCIITPDU = 6,       // big endian(2 bytes) tpdu(5 bytes) mensagem (n bytes) bigendiam = 5 bytes + n bytes da mensagem
        LITTLEASCIIPARTIAL = 7, // little endian (2 bytes) comente com o tamanho da mensagem no header
        XML = 8                 // sem tamanho, apenas para compatibilidade
    }
}
