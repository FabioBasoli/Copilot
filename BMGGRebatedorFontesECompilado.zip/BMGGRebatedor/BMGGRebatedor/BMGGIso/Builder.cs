using System;
using System.Linq;
using System.Text;
using BMGGRebatedor.Utils;
using System.Collections.Generic;

namespace BMGGRebatedor.BMGGIso
{
    public sealed class Builder
    {
        List<ModelBit> DE;
        Converters converter;

        #region create

        public Builder(List<ModelBit> DataElements)
        {
            DE = DataElements;
            converter = new Converters();
        }

        #endregion

        #region builder

        #region builder ASCII

        public byte[] Build(string[] arrayBits, string MTI, List<ModelBit> DE)
        {
            StringBuilder isoMessage = new StringBuilder();

            char[] bitmap = new char[130];
            for (int i = 0; i < bitmap.Length; i++) bitmap[i] = '0';

            bool hasSecondBitmap = false;
            for (int i = 2; i < 130; i++)
            {
                if (arrayBits[i] != null)
                {
                    hasSecondBitmap = i > 64 ? true : false;
                    bitmap[i] = '1';
                }
            }

            if (hasSecondBitmap) bitmap[1] = '1';

            string bitmap1 = new string(bitmap).Substring(1, 64);
            string bitmap2 = hasSecondBitmap == true ? new string(bitmap).Substring(65, 64) : string.Empty;

            bitmap1 = String.Format("{0:X1}", Convert.ToInt64(bitmap1, 2)).PadLeft(16, '0');
            bitmap2 = hasSecondBitmap == true ? String.Format("{0:X1}", Convert.ToInt64(bitmap2, 2)).PadLeft(16, '0') : string.Empty;

            isoMessage.Append(string.Format("{0}{1}{2}", MTI, bitmap1, bitmap2));

            for (int i = 2; i <= 128; i++)
            {
                if (!string.IsNullOrEmpty(arrayBits[i]))
                {
                    var typeBit = DE.Where(x => x.idBit == i).FirstOrDefault();
                    if (typeBit != null)
                    {
                        switch (typeBit.tipobit)
                        {
                            case ETipo.LLvar:
                                isoMessage.Append($"{arrayBits[i].Length:00}{arrayBits[i]}");
                                break;
                            case ETipo.LLLvar:
                                isoMessage.Append($"{arrayBits[i].Length:000}{arrayBits[i]}");
                                break;
                            default:
                                isoMessage.Append(arrayBits[i]);
                                break;
                        }
                    }
                }
            }

            return Encoding.ASCII.GetBytes(isoMessage.ToString());
        }

        public byte[] Build(string[] arrayBits, string MTI)
        {
            StringBuilder isoMessage = new StringBuilder();

            char[] bitmap = new char[130];
            for (int i = 0; i < bitmap.Length; i++) bitmap[i] = '0';

            bool hasSecondBitmap = false;
            for (int i = 2; i < 130; i++)
            {
                if (arrayBits[i] != null)
                {
                    hasSecondBitmap = i > 64 ? true : false;
                    bitmap[i] = '1';
                }
            }

            if (hasSecondBitmap) bitmap[1] = '1';

            string bitmap1 = new string(bitmap).Substring(1, 64);
            string bitmap2 = hasSecondBitmap == true ? new string(bitmap).Substring(65, 64) : string.Empty;

            bitmap1 = String.Format("{0:X1}", Convert.ToInt64(bitmap1, 2)).PadLeft(16, '0');
            bitmap2 = hasSecondBitmap == true ? String.Format("{0:X1}", Convert.ToInt64(bitmap2, 2)).PadLeft(16, '0') : string.Empty;

            isoMessage.Append(string.Format("{0}{1}{2}", MTI, bitmap1, bitmap2));

            for (int i = 2; i <= 128; i++)
            {
                isoMessage.Append(arrayBits[i]);
            }

            return Encoding.ASCII.GetBytes(isoMessage.ToString());
        }

        #endregion

        #region builder Elo

        public byte[] Build(string[] arrayBits, string MTI, int[] bitesHexa)
        {
            List<byte> isoMessage = new List<byte>();

            char[] bitmap = new char[130];
            for (int i = 0; i < bitmap.Length; i++) bitmap[i] = '0';

            bool hasSecondBitmap = false;
            for (int i = 2; i < 130; i++)
            {
                if (arrayBits[i] != null)
                {
                    hasSecondBitmap = i > 64 ? true : false;
                    bitmap[i] = '1';
                }
            }

            if (hasSecondBitmap) bitmap[1] = '1';

            string bitmap1 = new string(bitmap).Substring(1, 64);
            string bitmap2 = hasSecondBitmap == true ? new string(bitmap).Substring(65, 64) : string.Empty;

            bitmap1 = String.Format("{0:X1}", Convert.ToInt64(bitmap1, 2)).PadLeft(16, '0');
            bitmap2 = hasSecondBitmap == true ? String.Format("{0:X1}", Convert.ToInt64(bitmap2, 2)).PadLeft(16, '0') : string.Empty;

            isoMessage.AddRange(Encoding.ASCII.GetBytes(string.Format("{0}{1}{2}", MTI, bitmap1, bitmap2)));

            for (int i = 2; i <= 128; i++)
            {
                if (!string.IsNullOrEmpty(arrayBits[i]))
                {
                    if (bitesHexa.Any(x => x == i))
                        isoMessage.AddRange(FormataHexa(i, arrayBits[i]));
                    else
                        isoMessage.AddRange(Encoding.ASCII.GetBytes(arrayBits[i]));
                }
            }

            return isoMessage.ToArray();
        }

        #endregion

        #region builder Master

        public byte[] BuildMaster(string[] arrayBits, string MTI)
        {
            arrayBits[52] = null;

            char[] bitmap = new char[130];
            for (int i = 0; i < bitmap.Length; i++) bitmap[i] = '0';

            bool hasSecondBitmap = false;
            for (int i = 2; i < 130; i++)
            {
                if (arrayBits[i] != null)
                {
                    hasSecondBitmap = i > 64 ? true : false;
                    bitmap[i] = '1';
                }
            }

            if (hasSecondBitmap) bitmap[1] = '1';

            string bitmap1 = new string(bitmap).Substring(1, 64);
            string bitmap2 = hasSecondBitmap == true ? new string(bitmap).Substring(65, 64) : string.Empty;

            List<byte> isoMessage = new List<byte>();
            isoMessage.AddRange(Encoding.ASCII.GetBytes(MTI));
            isoMessage.AddRange(converter.BinaryToHexArray(bitmap1));
            if (hasSecondBitmap) isoMessage.AddRange(converter.BinaryToHexArray(bitmap2));


            for (int i = 2; i <= 128; i++)
            {
                if (arrayBits[i] != null)
                {
                    var bit = DE.Where(x => x.idBit == i).FirstOrDefault();
                    switch (bit.tipobit)
                    {
                        case ETipo.Numeric:
                        case ETipo.Alphanumeric:
                        case ETipo.Amount:
                        case ETipo.Lvar:
                        case ETipo.LLvar:
                        case ETipo.LLLvar:
                            isoMessage.AddRange(Encoding.ASCII.GetBytes(arrayBits[i]));
                            break;
                        case ETipo.FixedBinary:
                            isoMessage.AddRange(converter.AsciiToHexArray(arrayBits[i]));
                            break;
                        case ETipo.LLvarBinary:
                            var lengthLL = arrayBits[i].Substring(0, 2);
                            var valueLL = arrayBits[i].Substring(2);
                            isoMessage.AddRange(Encoding.ASCII.GetBytes(lengthLL));
                            isoMessage.AddRange(converter.AsciiToHexArray(valueLL));
                            break;
                        case ETipo.LLLvarBinary:
                            var lengthLLL = (Convert.ToInt32(arrayBits[i].Length) / 2).ToString().PadLeft(3, '0');
                            var valueLLL = arrayBits[i];
                            isoMessage.AddRange(Encoding.ASCII.GetBytes(lengthLLL));
                            isoMessage.AddRange(converter.AsciiToHexArray(valueLLL));
                            break;
                    }
                }
            }

            return isoMessage.ToArray();
        }

        #endregion

        #endregion

        #region cria bit

        public void CriaBit(ref string[] array, string bitname, string valor)
        {
            ModelBit model = DE.Where(x => x.nomeBit.Equals(bitname)).First();
            if (model != null)
            {
                if (model.tipobit != ETipo.Owner)
                {
                    switch (model.tipobit)
                    {
                        #region ASCII

                        case ETipo.Numeric:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.Alphanumeric:
                            array[model.idBit] = valor.PadRight(model.tamanhoBit, ' ');
                            break;
                        case ETipo.Amount:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.Lvar:
                            array[model.idBit] = string.Format("{0}{1}", valor.Length.ToString(), valor);
                            break;
                        case ETipo.LLvar:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0}{1}", valor.Length.ToString().PadLeft(2, '0'), valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLvar:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLLvar:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                            }

                            break;

                        #endregion

                        #region BINARY

                        case ETipo.FixedBinary:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.LvarBinary: // para visa o tamanho sera colocado no builder
                            array[model.idBit] = valor;
                            break;
                        case ETipo.LLvarBinary:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:00}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLvarBinary:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLLvarBinary:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:0000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                            }

                            break;

                        #endregion

                        #region binary BCD/EBCDIC

                        case ETipo.LvarBinaryBCD:
                            array[model.idBit] = valor;
                            break;
                        case ETipo.LvarBinaryEBCDIC:
                            array[model.idBit] = valor;
                            break;

                        #endregion

                        #region BCD

                        case ETipo.NumericBCD:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.AmountBCD:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.LLvarBCD:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:00}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLvarBCD:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLLvarBCD:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:0000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                            }

                            break;

                        #endregion

                        #region EBCDIC

                        case ETipo.NumericEBCDIC:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.AlphanumericEBCDIC:
                            array[model.idBit] = valor.PadRight(model.tamanhoBit, ' ');
                            break;
                        case ETipo.AmountEBCDIC:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.LLvarEBCDIC:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:00}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLvarEBCDIC:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLLvarEBCDIC:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:0000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                            }

                            break;

                        #endregion

                        #region ARRAY

                        case ETipo.ArrayByte:
                            array[model.idBit] = valor;
                            break;
                        case ETipo.LLvarArrayByte:
                            array[model.idBit] = valor;
                            break;

                        #endregion
                    }
                }
            }
        }

        public void CriaBit(ref string[] array, int bitId, string valor)
        {
            ModelBit model = DE.Where(x => x.idBit == bitId).First();
            if (model != null)
            {
                if (model.tipobit != ETipo.Owner)
                {
                    switch (model.tipobit)
                    {
                        #region ASCII

                        case ETipo.Numeric:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.Alphanumeric:
                            array[model.idBit] = valor.PadRight(model.tamanhoBit, ' ');
                            break;
                        case ETipo.Amount:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.Lvar:
                            array[model.idBit] = string.Format("{0}{1}", valor.Length.ToString(), valor);
                            break;
                        case ETipo.LLvar:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0}{1}", valor.Length.ToString().PadLeft(2, '0'), valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLvar:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLLvar:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                            }

                            break;

                        #endregion

                        #region BINARY

                        case ETipo.FixedBinary:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.LvarBinary: // para visa o tamanho sera colocado no builder
                            array[model.idBit] = valor;
                            break;
                        case ETipo.LLvarBinary:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:00}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLvarBinary:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLLvarBinary:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:0000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                            }

                            break;

                        #endregion

                        #region binary BCD/EBCDIC

                        case ETipo.LvarBinaryBCD:
                            array[model.idBit] = valor;
                            break;
                        case ETipo.LvarBinaryEBCDIC:
                            array[model.idBit] = valor;
                            break;

                        #endregion

                        #region BCD

                        case ETipo.NumericBCD:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.AmountBCD:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.LLvarBCD:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:00}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLvarBCD:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLLvarBCD:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:0000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                            }

                            break;

                        #endregion

                        #region EBCDIC

                        case ETipo.NumericEBCDIC:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.AlphanumericEBCDIC:
                            array[model.idBit] = valor.PadRight(model.tamanhoBit, ' ');
                            break;
                        case ETipo.AmountEBCDIC:
                            array[model.idBit] = valor.PadLeft(model.tamanhoBit, '0');
                            break;
                        case ETipo.LLvarEBCDIC:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:00}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(2, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(2, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:00}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLvarEBCDIC:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(3, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(3, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:000}{1}", bitNovo.Length, bitNovo);

                                    array[model.idBit] = OrdenaBitTlv(array[model.idBit]);
                                }
                            }

                            break;
                        case ETipo.LLLLvarEBCDIC:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = string.Format("{0:0000}{1}", valor.Length, valor);
                            }
                            else
                            {
                                if (array[model.idBit] == null)
                                {
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}", id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                                else
                                {
                                    string bitExistente = array[model.idBit].Substring(3, array[model.idBit].Length - 3);
                                    string id = model.idTlv.ToString().PadLeft(4, '0');
                                    string val = valor;
                                    string tam = val.Length.ToString().PadLeft(4, '0');
                                    string bitNovo = string.Format("{0}{1}{2}{3}", bitExistente, id, tam, val);
                                    array[model.idBit] = string.Format("{0:0000}{1}", bitNovo.Length, bitNovo);
                                }
                            }

                            break;

                        #endregion

                        #region ARRAY

                        case ETipo.ArrayByte:
                            array[model.idBit] = valor;
                            break;
                        case ETipo.LLvarArrayByte:
                            array[model.idBit] = valor;
                            break;

                        #endregion
                    }
                }
            }
        }

        #endregion

        #region array multidimensional (Visa)

        public void CriaBit(ref byte[][] array, int bitname, string valor)
        {
            ModelBit model = DE.Where(x => x.idBit == bitname).First();
            if (model != null)
            {
                if (model.tipobit != ETipo.Owner)
                {
                    switch (model.tipobit)
                    {
                        #region ASCII

                        case ETipo.Numeric:
                            array[model.idBit] = Encoding.ASCII.GetBytes(valor.PadLeft(model.tamanhoBit, '0'));
                            break;
                        case ETipo.Alphanumeric:
                            array[model.idBit] = Encoding.ASCII.GetBytes(valor.PadRight(model.tamanhoBit, ' '));
                            break;
                        case ETipo.Amount:
                            array[model.idBit] = Encoding.ASCII.GetBytes(valor.PadLeft(model.tamanhoBit, '0'));
                            break;
                        case ETipo.Lvar:
                            array[model.idBit] = Encoding.ASCII.GetBytes(valor);
                            break;
                        case ETipo.LLvar:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = Encoding.ASCII.GetBytes(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(2, '0');
                                string tam = valor.Length.ToString().PadLeft(2, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = Encoding.ASCII.GetBytes($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(Encoding.ASCII.GetBytes($"{id}{tam}{valor}")).ToArray();
                            }

                            break;
                        case ETipo.LLLvar:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = Encoding.ASCII.GetBytes(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(3, '0');
                                string tam = valor.Length.ToString().PadLeft(3, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = Encoding.ASCII.GetBytes($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(Encoding.ASCII.GetBytes($"{id}{tam}{valor}")).ToArray();
                            }

                            break;
                        case ETipo.LLLLvar:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = Encoding.ASCII.GetBytes(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(4, '0');
                                string tam = valor.Length.ToString().PadLeft(4, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = Encoding.ASCII.GetBytes($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(Encoding.ASCII.GetBytes($"{id}{tam}{valor}")).ToArray();
                            }

                            break;

                        #endregion

                        #region BCD

                        case ETipo.NumericBCD:
                            array[model.idBit] = converter.StrToBcd(valor.PadLeft(model.tamanhoBit, '0'));
                            break;
                        case ETipo.AmountBCD:
                            array[model.idBit] = converter.StrToBcd(valor.PadLeft(model.tamanhoBit, '0'));
                            break;
                        case ETipo.LvarBCD:
                            array[model.idBit] = converter.StrToBcd(valor);
                            break;
                        case ETipo.LLvarBCD:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = converter.StrToBcd(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(2, '0');
                                string tam = valor.Length.ToString().PadLeft(2, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = converter.StrToBcd($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(converter.StrToBcd($"{id}{tam}{valor}")).ToArray();
                            }

                            break;
                        case ETipo.LLLvarBCD:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = converter.StrToBcd(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(3, '0');
                                string tam = valor.Length.ToString().PadLeft(3, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = converter.StrToBcd($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(converter.StrToBcd($"{id}{tam}{valor}")).ToArray();
                            }

                            break;
                        case ETipo.LLLLvarBCD:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = converter.StrToBcd(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(4, '0');
                                string tam = valor.Length.ToString().PadLeft(4, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = converter.StrToBcd($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(converter.StrToBcd($"{id}{tam}{valor}")).ToArray();
                            }

                            break;
                        case ETipo.LvarDecimalBcd:
                            array[model.idBit] = converter.StrToBcd(valor);
                            break;
                        case ETipo.LvarDecimalBCDPan:
                            valor = valor.Length % 2 == 0 ? valor : $"0{valor}";
                            array[model.idBit] = converter.StrToBcd(valor);
                            break;

                        #endregion

                        #region EBCDIC

                        case ETipo.NumericEBCDIC:
                            array[model.idBit] = converter.AsciiToEbcDic(valor.PadLeft(model.tamanhoBit, '0'));
                            break;
                        case ETipo.AlphanumericEBCDIC:
                            array[model.idBit] = converter.AsciiToEbcDic(valor.PadRight(model.tamanhoBit, ' '));
                            break;
                        case ETipo.AmountEBCDIC:
                            array[model.idBit] = converter.AsciiToEbcDic(valor.PadLeft(model.tamanhoBit, '0'));
                            break;
                        case ETipo.LLvarEBCDIC:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = converter.AsciiToEbcDic(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(2, '0');
                                string tam = valor.Length.ToString().PadLeft(2, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = converter.StrToBcd($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(converter.AsciiToEbcDic($"{id}{tam}{valor}")).ToArray();
                            }

                            break;
                        case ETipo.LLLvarEBCDIC:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = converter.AsciiToEbcDic(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(3, '0');
                                string tam = valor.Length.ToString().PadLeft(3, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = converter.StrToBcd($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(converter.AsciiToEbcDic($"{id}{tam}{valor}")).ToArray();
                            }

                            break;
                        case ETipo.LLLLvarEBCDIC:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = converter.AsciiToEbcDic(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(4, '0');
                                string tam = valor.Length.ToString().PadLeft(4, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = converter.StrToBcd($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(converter.AsciiToEbcDic($"{id}{tam}{valor}")).ToArray();
                            }

                            break;

                        #endregion

                        #region BINARY

                        case ETipo.FixedBinary:
                            array[model.idBit] = converter.AsciiToHexArray(valor.PadLeft(model.tamanhoBit, '0'));
                            break;
                        case ETipo.LvarBinary:
                            array[model.idBit] = converter.AsciiToHexArray(valor);
                            break;
                        case ETipo.LLvarBinary:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = converter.AsciiToHexArray(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(2, '0');
                                string tam = valor.Length.ToString().PadLeft(2, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = converter.AsciiToHexArray($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(converter.AsciiToHexArray($"{id}{tam}{valor}")).ToArray();
                            }

                            break;
                        case ETipo.LLLvarBinary:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = converter.AsciiToHexArray(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(3, '0');
                                string tam = valor.Length.ToString().PadLeft(3, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = converter.AsciiToHexArray($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(converter.AsciiToHexArray($"{id}{tam}{valor}")).ToArray();
                            }

                            break;
                        case ETipo.LLLLvarBinary:
                            if (model.idTlv.Equals(""))
                            {
                                array[model.idBit] = converter.AsciiToHexArray(valor);
                            }
                            else
                            {
                                string id = model.idTlv.ToString().PadLeft(4, '0');
                                string tam = valor.Length.ToString().PadLeft(4, '0');

                                if (array[model.idBit] == null)
                                    array[model.idBit] = converter.AsciiToHexArray($"{id}{tam}{valor}");
                                else
                                    array[model.idBit] = array[model.idBit].Concat(converter.AsciiToHexArray($"{id}{tam}{valor}")).ToArray();
                            }

                            break;

                        #endregion

                        #region BINARY-BCD

                        case ETipo.LvarBinaryBCD:
                            valor = valor.Length % 2 != 0 ? valor = $"0{valor}" : valor;
                            array[model.idBit] = converter.StrToBcd(valor);
                            break;

                        #endregion

                        #region BINARY-EBCDIC

                        case ETipo.LvarBinaryEBCDIC:
                            array[model.idBit] = converter.AsciiToEbcDic(valor);
                            break;

                        #endregion

                        #region BCD-BINARY

                        case ETipo.LvarBcdBinary:
                            var strLvarBcdBinary = converter.HexToBinary(valor);
                            array[model.idBit] = converter.BinaryToHexArray(strLvarBcdBinary);
                            break;

                        #endregion

                        #region DECIMAL-BINARY

                        case ETipo.DecimalBinary:
                            var valueBinary = converter.HexToBinary(valor);
                            array[model.idBit] = converter.BinaryToHexArray(valueBinary);
                            break;
                        case ETipo.LvarDecimalBynary:
                            var LvalueBinary = converter.HexToBinary(valor);
                            array[model.idBit] = converter.BinaryToHexArray(LvalueBinary);
                            break;
                        case ETipo.LvarDecimalBynaryPan:
                            valor = valor.Length % 2 == 0 ? valor : $"0{valor}";
                            var LvalueBinaryPan = converter.HexToBinary(valor);
                            array[model.idBit] = converter.BinaryToHexArray(LvalueBinaryPan);
                            break;

                        #endregion
                    }
                }
            }
        }

        public byte[] Build(byte[][] arrayBits, string MTI)
        {
            int size = arrayBits.Length;
            List<byte> isoMessage = new List<byte>();

            char[] bitmap = new char[size];
            for (int i = 0; i < bitmap.Length; i++) bitmap[i] = '0';

            bool hasSecondBitmap = false;
            bool hasThirdBitmap = false;
            for (int i = 2; i < size; i++)
            {
                if (arrayBits[i] != null)
                {
                    hasSecondBitmap = i > 64 ? true : false;
                    hasThirdBitmap = i > 128 ? true : false;
                    bitmap[i] = '1';
                }
            }

            if (hasSecondBitmap) bitmap[1] = '1';
            if (hasThirdBitmap) bitmap[65] = '1';

            string bitmap1 = new string(bitmap).Substring(1, 64);
            string bitmap2 = hasSecondBitmap == true ? new string(bitmap).Substring(65, 64) : string.Empty;
            string bitmap3 = hasThirdBitmap == true ? new string(bitmap).Substring(129, 64) : string.Empty;

            isoMessage.AddRange(converter.StrToBcd(MTI));
            isoMessage.AddRange(converter.BinaryToHexArray(bitmap1));
            if (hasSecondBitmap) isoMessage.AddRange(converter.BinaryToHexArray(bitmap2));
            if (hasThirdBitmap) isoMessage.AddRange(converter.BinaryToHexArray(bitmap3));

            for (int i = 2; i < size; i++)
            {
                if (arrayBits[i] != null)
                {
                    var bit = DE.Where(x => x.idBit == i).FirstOrDefault();
                    switch (bit.tipobit)
                    {
                        #region ASCII

                        case ETipo.Amount:
                        case ETipo.Numeric:
                        case ETipo.Alphanumeric:
                            isoMessage.AddRange(arrayBits[i]);
                            break;
                        case ETipo.Lvar:
                            var lvar = Encoding.ASCII.GetBytes(arrayBits[i].Length.ToString());
                            isoMessage.AddRange(lvar.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLvar:
                            var llvar = Encoding.ASCII.GetBytes(arrayBits[i].Length.ToString().PadLeft(2, '0'));
                            isoMessage.AddRange(llvar.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLLvar:
                            var lllvar = Encoding.ASCII.GetBytes(arrayBits[i].Length.ToString().PadLeft(3, '0'));
                            isoMessage.AddRange(lllvar.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLLLvar:
                            var llllvar = Encoding.ASCII.GetBytes(arrayBits[i].Length.ToString().PadLeft(4, '0'));
                            isoMessage.AddRange(llllvar.Concat(arrayBits[i]));
                            break;

                        #endregion

                        #region BCD

                        case ETipo.NumericBCD:
                        case ETipo.AmountBCD:
                            isoMessage.AddRange(arrayBits[i]);
                            break;
                        case ETipo.LvarBCD:
                            var lvarbcd = converter.StrToBcd(arrayBits[i].Length.ToString().PadLeft(2, '0'));
                            isoMessage.AddRange(lvarbcd.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLvarBCD:
                            var llvarbcd = converter.StrToBcd(arrayBits[i].Length.ToString().PadLeft(2, '0'));
                            isoMessage.AddRange(llvarbcd.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLLvarBCD:
                            var lllvarbcd = converter.StrToBcd(arrayBits[i].Length.ToString().PadLeft(3, '0'));
                            isoMessage.AddRange(lllvarbcd.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLLLvarBCD:
                            var llllvarbcd = converter.StrToBcd(arrayBits[i].Length.ToString().PadLeft(4, '0'));
                            isoMessage.AddRange(llllvarbcd.Concat(arrayBits[i]));
                            break;
                        case ETipo.LvarDecimalBcd:
                            var lvarDecimalBcd = converter.AsciiToHexArray((arrayBits[i].Length * 2).ToString("X2"));
                            isoMessage.AddRange(lvarDecimalBcd.Concat(arrayBits[i]));
                            break;
                        case ETipo.LvarDecimalBCDPan:
                            var vAuxPan = BitConverter.ToString(arrayBits[i], 0, 1);
                            var vAuxPanSize = vAuxPan.StartsWith("0") ? (arrayBits[i].Length * 2) - 1 : arrayBits[i].Length * 2;
                            var vAuxPanHex = converter.AsciiToHexArray(vAuxPanSize.ToString("X2"));
                            isoMessage.AddRange(vAuxPanHex.Concat(arrayBits[i]));
                            break;

                        #endregion

                        #region EBCDIC

                        case ETipo.AmountEBCDIC:
                        case ETipo.NumericEBCDIC:
                        case ETipo.AlphanumericEBCDIC:
                            isoMessage.AddRange(arrayBits[i]);
                            break;
                        case ETipo.LLvarEBCDIC:
                            var llvarebcdic = Encoding.GetEncoding("IBM037").GetBytes(arrayBits[i].Length.ToString().PadLeft(2, '0'));
                            isoMessage.AddRange(llvarebcdic.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLLvarEBCDIC:
                            var lllvarebcdic = Encoding.GetEncoding("IBM037").GetBytes(arrayBits[i].Length.ToString().PadLeft(3, '0'));
                            isoMessage.AddRange(lllvarebcdic.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLLLvarEBCDIC:
                            var llllvarebcdic = Encoding.GetEncoding("IBM037").GetBytes(arrayBits[i].Length.ToString().PadLeft(4, '0'));
                            isoMessage.AddRange(llllvarebcdic.Concat(arrayBits[i]));
                            break;

                        #endregion

                        #region BINARY

                        case ETipo.FixedBinary:
                            isoMessage.AddRange(arrayBits[i]);
                            break;
                        case ETipo.LvarBinary:
                            var lvarbinary = converter.AsciiToHexArray(arrayBits[i].Length.ToString("X2"));
                            isoMessage.AddRange(lvarbinary.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLvarBinary:
                            var llvarbinary = converter.AsciiToHexArray(arrayBits[i].Length.ToString("X2").PadLeft(4, '0'));
                            isoMessage.AddRange(llvarbinary.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLLvarBinary:
                            var lllvarbinary = converter.AsciiToHexArray(arrayBits[i].Length.ToString("X2").PadLeft(6, '0'));
                            isoMessage.AddRange(lllvarbinary.Concat(arrayBits[i]));
                            break;
                        case ETipo.LLLLvarBinary:
                            var llllvarbinary = converter.AsciiToHexArray(arrayBits[i].Length.ToString("X2").PadLeft(8, '0'));
                            isoMessage.AddRange(llllvarbinary.Concat(arrayBits[i]));
                            break;

                        #endregion

                        #region BINARY-BCD

                        case ETipo.LvarBinaryBCD:
                            var lvarbinarybcd = converter.AsciiToHexArray(arrayBits[i].Length.ToString("X2"));
                            isoMessage.AddRange(lvarbinarybcd.Concat(arrayBits[i]));
                            break;

                        #endregion

                        #region BINARY-EBCDIC

                        case ETipo.LvarBinaryEBCDIC:
                            var lvarbinaryebcdic = converter.AsciiToHexArray(arrayBits[i].Length.ToString("X2"));
                            isoMessage.AddRange(lvarbinaryebcdic.Concat(arrayBits[i]));
                            break;

                        #endregion

                        #region BCD-BINARY

                        case ETipo.LvarBcdBinary:
                            var lvarbcdbinary = new byte[1] {Convert.ToByte(arrayBits[i].Length * 2)};
                            isoMessage.AddRange(lvarbcdbinary.Concat(arrayBits[i]));
                            break;

                        #endregion

                        #region DECIMAL-BINARY

                        case ETipo.DecimalBinary:
                            isoMessage.AddRange(arrayBits[i]);
                            break;
                        case ETipo.LvarDecimalBynary:
                            var lvarDecBinary = converter.AsciiToHexArray((arrayBits[i].Length * 2).ToString("X2"));
                            isoMessage.AddRange(lvarDecBinary.Concat(arrayBits[i]));
                            break;
                        case ETipo.LvarDecimalBynaryPan:
                            var vDecPan = BitConverter.ToString(arrayBits[i], 0, 1);
                            var vDecPanSize = vDecPan.StartsWith("0") ? (arrayBits[i].Length * 2) - 1 : arrayBits[i].Length * 2;
                            var vDecPanHex = converter.AsciiToHexArray(vDecPanSize.ToString("X2"));
                            isoMessage.AddRange(vDecPanHex.Concat(arrayBits[i]));
                            break;

                        #endregion

                        #region Array pre formatado

                        case ETipo.ArrayPreFormatado:
                            var lvarbinaryPre = converter.AsciiToHexArray(arrayBits[i].Length.ToString("X2"));
                            isoMessage.AddRange(lvarbinaryPre.Concat(arrayBits[i]));
                            break;

                        #endregion
                    }
                }
            }

            return isoMessage.ToArray();
        }

        #endregion

        #region ordena bit tlv

        private string OrdenaBitTlv(string bitOriginal)
        {
            // List<FormatTLV> tlvList = new List<FormatTLV>();
            //
            // string bitSemTamanho = bitOriginal.Substring(3, bitOriginal.Length - 3);
            //
            // bool continua = true;
            //
            // string resultado = string.Empty;
            //
            // if (!bitSemTamanho.StartsWith("*"))
            // {
            //     while (continua)
            //     {
            //         int id = Convert.ToInt32(bitSemTamanho.Substring(0, 3));
            //         int tam = Convert.ToInt32(bitSemTamanho.Substring(3, 3));
            //         string valor = bitSemTamanho.Substring(6, tam);
            //         bitSemTamanho = bitSemTamanho.Remove(0, tam + 6);
            //
            //         FormatTLV tlv = new FormatTLV(id, tam, valor);
            //         tlvList.Add(tlv);
            //
            //         if (bitSemTamanho.Length <= 0)
            //             continua = false;
            //     }
            //
            //     List<FormatTLV> tlvListOrdenado = tlvList.OrderBy(x => x.id).ToList();
            //
            //     foreach (var item in tlvListOrdenado)
            //     {
            //         resultado += string.Format("{0:000}{1:000}{2}", item.id, item.tamanho, item.valor);
            //     }
            //
            //     return string.Format("{0:000}{1}", resultado.Length, resultado);
            // }
            // else
            // {
            //     return bitOriginal;
            // }
            return bitOriginal;
        }

        #endregion

        #region formata hexa

        private byte[] FormataHexa(int bit, string value)
        {
            int size = 0;
            List<byte> array = new List<byte>();

            ModelBit model = DE.Where(x => x.idBit == bit).First();
            if (model != null)
            {
                switch (model.tipobit)
                {
                    case ETipo.Amount:
                    case ETipo.Numeric:
                    case ETipo.Alphanumeric:
                        array.AddRange(converter.StringToByteArrayBase16(value));
                        return array.ToArray();
                    case ETipo.LLvar:
                        size = (value.Length - 2) / 2;
                        array.AddRange(Encoding.ASCII.GetBytes(size.ToString().PadLeft(2, '0')));
                        array.AddRange(converter.StringToByteArrayBase16(value.Substring(2)));
                        return array.ToArray();
                    case ETipo.LLLvar:
                        size = (value.Length - 3) / 2;
                        array.AddRange(Encoding.ASCII.GetBytes(size.ToString().PadLeft(3, '0')));
                        array.AddRange(converter.StringToByteArrayBase16(value.Substring(3)));
                        return array.ToArray();
                    default: return new byte[0];
                }
            }
            else
            {
                return new byte[0];
            }
        }

        #endregion
    }
}