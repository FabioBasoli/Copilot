﻿using System;
using System.Linq;
using System.Text;
using BMGGRebatedor.Utils;
using System.Collections.Generic;

namespace BMGGRebatedor.BMGGIso
{
    public class ParserBase
    {
        public ETipo fieldType;

        public List<ModelBit> DE;

        #region set field type
        internal void SetFieldType(int bit)
        {
            fieldType = DE.Where(x => x.idBit == bit).Select(x => x.tipobit).First();
        }
        #endregion

        #region get bit lenght
        internal int GetLen(int bit)
        {
            return DE.Where(x => x.idBit == bit).Select(x => x.tamanhoBit).First();
        }
        #endregion

        #region funções para binary
        internal string BitMaptoBinary(string HexDE)
        {
            string deBinary = "";
            for (int I = 0; I <= 15; I++)
            {
                deBinary = deBinary + Hex2Binary(HexDE.Substring(I, 1));
            }
            return deBinary;
        }

        internal string BitMaptoBinarySmall(string HexDE)
        {
            string deBinary = "";
            for (int I = 0; I < HexDE.Length; I++)
            {
                deBinary = deBinary + Hex2Binary(HexDE.Substring(I, 1));
            }
            return deBinary;
        }

        private string Hex2Binary(string bit)
        {
            string myBinary = "";
            switch (bit)
            {
                case "0": myBinary = "0000"; break;
                case "1": myBinary = "0001"; break;
                case "2": myBinary = "0010"; break;
                case "3": myBinary = "0011"; break;
                case "4": myBinary = "0100"; break;
                case "5": myBinary = "0101"; break;
                case "6": myBinary = "0110"; break;
                case "7": myBinary = "0111"; break;
                case "8": myBinary = "1000"; break;
                case "9": myBinary = "1001"; break;
                case "A": myBinary = "1010"; break;
                case "B": myBinary = "1011"; break;
                case "C": myBinary = "1100"; break;
                case "D": myBinary = "1101"; break;
                case "E": myBinary = "1110"; break;
                case "F": myBinary = "1111"; break;
            }
            return myBinary;
        }

        #endregion

        #region read partial byte array
        internal string ReadPartialStringByArray(byte[] arr, int inicio, int final)
        {
            byte[] arrParcial = new byte[final];
            Buffer.BlockCopy(arr, inicio, arrParcial, 0, final);
            return Encoding.ASCII.GetString(arrParcial);
        }

        internal string ReadPartialStringByArray(byte[] arr, int inicio, int final, EDataType dataTipo)
        {
            byte[] arrParcial = new byte[final];
            Buffer.BlockCopy(arr, inicio, arrParcial, 0, final);
            Converters converter = new Converters();

            switch (dataTipo)
            {
                case EDataType.HEXA:
                    return converter.DecimalToHex(arrParcial);
                case EDataType.EBCDIC:
                    return converter.EbcDicToAscii(arrParcial);
                case EDataType.BCD:
                    return converter.BcdToStr(arrParcial);
                case EDataType.DECIMAL:
                    return Convert.ToInt32(arrParcial[0]).ToString();
                default: return string.Empty;
            }
        }
        #endregion

        #region Método de decodificação de campos TLV
        internal List<FormatTLV> ParseTLV(string ISOmsg)
        {
            int posicao = 0;
            int tamanho = 3;
            string newIso = ISOmsg;
            bool verificacao = true;
            List<FormatTLV> retorno = new List<FormatTLV>();

            while (verificacao)
            {
                int id = Convert.ToInt16(newIso.Substring(posicao, tamanho));
                posicao += tamanho;
                int tam = Convert.ToInt16(newIso.Substring(posicao, tamanho));
                posicao += tamanho;
                string val = newIso.Substring(posicao, tam);
                posicao = posicao + tam;

                retorno.Add(new FormatTLV(id, tam, val));

                if (newIso.Length == posicao) verificacao = false;
            }
            return retorno;
        }

        public List<FormatTLV> ParseSFD(string ISOmsg)
        {
            int posicao = 4;
            int tamanho = 0;

            List<FormatTLV> retorno = new List<FormatTLV>();

            while (posicao < ISOmsg.Length)
            {
                // ler tamanho do campo
                tamanho = 4;
                int tamanhoField = Convert.ToInt16(ISOmsg.Substring(posicao, tamanho));
                posicao += tamanho;
                // ler indice
                tamanho = 2;
                int indiceField = Convert.ToInt16(ISOmsg.Substring(posicao, tamanho));
                posicao += tamanho;
                // ler valor do campo
                string valorField = ISOmsg.Substring(posicao, tamanhoField - 2);
                posicao += tamanhoField - 2;

                retorno.Add(new FormatTLV(indiceField, tamanhoField, valorField));
            }
            return retorno;
        }
        #endregion

    }
}
