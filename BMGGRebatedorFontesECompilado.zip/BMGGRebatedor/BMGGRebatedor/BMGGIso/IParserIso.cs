﻿using System.Collections.Generic;

namespace BMGGRebatedor.BMGGIso
{
    public interface IParserIso
    {
        IParserIso Instantiate(List<ModelBit> DataElements);

        string[] ReadIso(byte[] array);
    }
}
