﻿namespace BMGGRebatedor.BMGGIso
{
    public enum ETipo
    {
        // ASCII
        Numeric,
        Alphanumeric,
        Amount,
        Lvar,
        LLvar,
        LLLvar,
        LLLLvar,
        Owner,

        // BINARY
        FixedBinary,
        LvarBinary,
        LLvarBinary,
        LLLvarBinary,
        LLLLvarBinary,

        // BINARY AND TYPES
        LvarBinaryBCD,
        LvarBinaryEBCDIC,

        // BCD AND BINARY
        DecimalBinary,
        LvarDecimalBCD,
        LvarDecimalBCDPan,
        LvarDecimalBynary,
        LvarDecimalBynaryPan,
        LvarBcdBinary,

        // BCD
        NumericBCD,
        AmountBCD,
        AlphanumericBCD,
        LvarBCD,
        LLvarBCD,
        LLLvarBCD,
        LLLLvarBCD,
        LvarDecimalBcd,

        // EBCDIC
        NumericEBCDIC,
        AlphanumericEBCDIC,
        AmountEBCDIC,
        LLvarEBCDIC,
        LLLvarEBCDIC,
        LLLLvarEBCDIC,

        // ARRAY BYTE
        ArrayByte,
        LLvarArrayByte,

        // Array pre formatado
        ArrayPreFormatado
    }
}
