using System;
using System.Collections.Generic;

namespace BMGGRebatedor.BMGGIso.Parser
{
    sealed class ParserVisa : ParserBase, IParserIso
    {
        int FieldNo;
        int myPos = 0;
        int myLenght;

        string[] MessageArray;

        #region instantiate
        public IParserIso Instantiate(List<ModelBit> DataElements)
        {
            this.DE = new List<ModelBit>();
            this.DE = DataElements;
            return this;
        }
        #endregion

        #region read iso array
        public string[] ReadIso(byte[] array)
        {
            FieldNo = 0;
            myPos = 0;
            myLenght = 0;

            MessageArray = new string[200];

            string BitMap = "";
            string BitMap1Binary = "";
            string BitMap2Binary = "";
            string Bitmap3Binary = "";

            myPos = 4;
            myLenght = 1;

            string msgStatus = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);

            if (!msgStatus.Equals("16"))
            {
                myPos += 22;
                myLenght = 2;
                var R13 = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                myPos += 2;

                if (!string.IsNullOrEmpty(R13))
                {
                    var bitmapReaderError = BitMaptoBinarySmall(R13);
                    if (bitmapReaderError.StartsWith("1"))
                    {
                        MessageArray[196] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                        myPos += 2;
                    }
                }
            }

            myLenght = 1;
            msgStatus = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);

            if (msgStatus.Equals("16"))
            {
                myPos += 22;
                myLenght = 2;
                MessageArray[195] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                myPos += myLenght;
            }
            else
            {
                myLenght = 2;
                MessageArray[195] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                myPos += myLenght;
            }

            // read first bitmap
            myLenght = 8;
            MessageArray[0] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);

            BitMap1Binary = BitMaptoBinary(MessageArray[0]);

            // read second bitmap
            FieldNo = 1;
            if (BitMap1Binary.StartsWith("1"))
            {
                myPos += myLenght;
                myLenght = 8;
                MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                BitMap2Binary = BitMaptoBinary(MessageArray[FieldNo]);
            }

            FieldNo = 194;
            if (BitMap2Binary.StartsWith("1"))
            {
                myPos += myLenght;
                myLenght = 8;
                MessageArray[194] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                Bitmap3Binary = BitMaptoBinary(MessageArray[FieldNo]);
            }

            BitMap = $"{BitMap1Binary}{BitMap2Binary}{Bitmap3Binary}";

            // read all bits
            for (int i = 1; i < BitMap.Length; i++)
            {
                if (BitMap[i] == '1')
                {
                    FieldNo = i + 1;
                    SetFieldType(FieldNo);
                    myPos += myLenght;

                    if (FieldNo == 37)
                    {
                        var vAux = string.Empty;
                    }
                    switch (fieldType)
                    {
                        #region BCD
                        case ETipo.NumericBCD:
                        case ETipo.AmountBCD:
                            myLenght = GetLen(FieldNo);
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        case ETipo.LLvarBCD:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.BCD)); myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        case ETipo.LLLvarBCD:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 2, EDataType.BCD)); myPos += 2;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        case ETipo.LLLLvarBCD:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 2, EDataType.BCD)); myPos += 2;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        case ETipo.LvarDecimalBcd:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.DECIMAL)) / 2; myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        case ETipo.LvarDecimalBCDPan:
                            var vAuxPanSize = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.DECIMAL));
                            myLenght = vAuxPanSize % 2 == 0 ? vAuxPanSize / 2 : (vAuxPanSize + 1) / 2; myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        #endregion

                        #region EBCDIC
                        case ETipo.NumericEBCDIC:
                        case ETipo.AmountEBCDIC:
                        case ETipo.AlphanumericEBCDIC:
                            myLenght = GetLen(FieldNo);
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.EBCDIC);
                            break;
                        case ETipo.LLvarEBCDIC:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.BCD)); myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        case ETipo.LLLvarEBCDIC:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 2, EDataType.BCD)); myPos += 2;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        case ETipo.LLLLvarEBCDIC:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 3, EDataType.BCD)); myPos += 3;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        #endregion

                        #region ASCII
                        case ETipo.Numeric:
                        case ETipo.Alphanumeric:
                        case ETipo.Amount:
                            myLenght = GetLen(FieldNo);
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght);
                            break;
                        case ETipo.LLvar:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 2)); myPos += 2;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght);
                            break;
                        case ETipo.LLLvar:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 3)); myPos += 3;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght);
                            break;
                        case ETipo.LLLLvar:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 4)); myPos += 4;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght);
                            break;
                        #endregion

                        #region BINARY
                        case ETipo.FixedBinary:
                            myLenght = GetLen(FieldNo);
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                            break;
                        case ETipo.LvarBinary:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.DECIMAL)); myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                            break;
                        case ETipo.LLvarBinary:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 2)); myPos += 2;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                            break;
                        case ETipo.LLLvarBinary:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 3)); myPos += 3;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                            break;
                        case ETipo.LLLLvarBinary:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 4)); myPos += 4;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                            break;
                        #endregion

                        #region BINARY-BCD
                        case ETipo.LvarBinaryBCD:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.DECIMAL)); myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.BCD);
                            break;
                        #endregion

                        #region BINARY-EBCDIC
                        case ETipo.LvarBinaryEBCDIC:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.DECIMAL)); myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.EBCDIC);
                            break;
                        #endregion

                        #region BCD-BINARY
                        case ETipo.LvarBcdBinary:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.BCD)); myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                            break;
                        #endregion

                        #region DECIMAL-BINARY
                        case ETipo.DecimalBinary:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.DECIMAL)); myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                            break;
                        case ETipo.LvarDecimalBynary:
                            myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.DECIMAL))/2; myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                            break;
                        case ETipo.LvarDecimalBynaryPan:
                            var vDecPanSize = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 1, EDataType.DECIMAL));
                            myLenght = vDecPanSize % 2 == 0 ? vDecPanSize / 2 : (vDecPanSize + 1) / 2; myPos += 1;
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);
                            break;
                        #endregion

                        default:
                            myLenght = GetLen(FieldNo);
                            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght);
                            break;
                    }
                }
            }

            return MessageArray;
        }
        #endregion

    }
}