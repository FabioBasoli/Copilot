﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace BMGGRebatedor.BMGGIso.Parser
{
    public sealed class ParserBigAscTPDU : ParserBase, IParserIso
    {
        int FieldNo;
        int myPos = 0;
        int myLenght;

        string[] MessageArray;

        #region instantiate
        public IParserIso Instantiate(List<ModelBit> DataElements)
        {
            this.DE = new List<ModelBit>();
            this.DE = DataElements;
            return this;
        }
        #endregion

        #region read iso array
        public string[] ReadIso(byte[] array)
        {
            FieldNo = 0;
            myPos = 0;
            myLenght = 0;

            MessageArray = new string[130];
            string BitMap1Binary = "";
            string BitMap2Binary = "";

            myPos = 7;
            myLenght = 4;

            // read mti
            FieldNo = 129;

            MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght);
            myPos += myLenght;

            // read first bitmap
            myLenght = 16;
            MessageArray[0] = ReadPartialStringByArray(array, myPos, myLenght);
            BitMap1Binary = BitMaptoBinary(MessageArray[0]);

            // read second bitmap
            FieldNo = 1;
            if (BitMap1Binary.Substring(FieldNo - 1, 1) == "1")
            {
                myPos += myLenght;
                myLenght = 16;
                MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght);
                BitMap2Binary = BitMaptoBinary(MessageArray[FieldNo]);
                
                if (!string.IsNullOrEmpty(BitMap2Binary)) BitMap1Binary = BitMap1Binary + BitMap2Binary;
            }

            int[] bitsHexa = new[] {52, 55};
            
            for (int i = 1; i < BitMap1Binary.Length; i++)
            {
                if (BitMap1Binary[i] == '1')
                {
                    FieldNo = i + 1;
                    SetFieldType(FieldNo);
                    myPos += myLenght;

                    switch (fieldType)
                    {
                        case ETipo.LLvar: myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 2)); myPos += 2; break;
                        case ETipo.LLLvar: myLenght = Convert.ToInt32(ReadPartialStringByArray(array, myPos, 3)); myPos += 3; break;
                        default: myLenght = GetLen(FieldNo); break;
                    }

                    if (bitsHexa.Any(x => x == FieldNo))
                    {
                        MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght, EDataType.HEXA);   
                    }
                    else
                        MessageArray[FieldNo] = ReadPartialStringByArray(array, myPos, myLenght);
                }
            }

            return MessageArray;
        }
        #endregion

    }
}
