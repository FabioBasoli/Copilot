﻿namespace BMGGRebatedor.BMGGIso
{
    public sealed class TabelaBits
    {
        public int bit { get; set; }
        public string id { get; set; }
        public string valor { get; set; }

        public TabelaBits(int _bit, string _id, string _valor)
        {
            bit = _bit;
            id = _id;
            valor = _valor;
        }
    }
}
